<?php

/** File: includes/helper/static-data.php
 * Text Domain: accessschema-client
 * version 1.2.0
 *
 * @author greghacke
 * Function: Declarative static data for the plugin
 */

defined( 'ABSPATH' ) || exit;
