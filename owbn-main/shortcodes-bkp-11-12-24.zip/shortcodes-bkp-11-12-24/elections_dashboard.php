<?php
// Shortcode for Elections dashboard. This is the function that runs when the shortcode is
function elections_dashboard_shortcode()
{
    // Check if the user is logged in
    if (!is_user_logged_in() || (!current_user_can('administrator') && !current_user_can('author'))) {
        wp_die('You do not have permission to access this page.');
    }
    if (is_user_logged_in()) {
        // Get the current user's username
        $current_user = wp_get_current_user();
        $username = $current_user->user_login;

        // Fetch data from the database
        global $wpdb;
        $table_name = $wpdb->prefix . 'voting';
        // $results = $wpdb->get_results("SELECT * FROM $table_name");
        $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");


        $voting_options_json = json_encode($results);

        $running_votes = array_filter($results, function ($vote) {
            $votingStage = $vote->voting_stage;
            $closingDate = $vote->closing_date; // Assuming closingDate is a string in 'Y-m-d' format
            $today = strtotime(date('Y-m-d'));
            $activeStatus = $vote->active_status;

            // Check conditions
            if (
                $votingStage != 'draft' &&
                $votingStage != 'completed' &&
                $votingStage != 'withdrawn' &&
//                 $votingStage != 'autopass' &&
                $closingDate >= $today &&
                $activeStatus == 'activeVote'
            ) {
                return true;
            }
            return false;
        });
        $completed_votes = array_filter($results, function ($vote) {
            $votingStage = $vote->voting_stage;
            $closingDate = $vote->closing_date; // Assuming closingDate is a string in 'Y-m-d' format
            $today = strtotime(date('Y-m-d'));

            // Check conditions
           // if ($votingStage === 'completed' || $closingDate < $today) {
            if ($votingStage === 'completed') {
                return true;
            }
            return false;
        });

        $draft_votes = array_filter($results, function ($vote) {
            $votingStage = $vote->voting_stage;
            $closingDate = $vote->closing_date; // Assuming closingDate is a string in 'Y-m-d' format
            $today = strtotime(date('Y-m-d'));

            // Check conditions
            if ($votingStage === 'draft') {
                return true;
            }
            return false;
        });

        $voting_options_json1 = json_encode($running_votes);

        // Display the dashboard content HTML
        ob_start();
?>
        <section class="owbnVP custom-section election_dashboard">
            <div class="wrapper">
                <div class="tab--section">
                    <div class="tab--wrapper">
                        <div class="tabs">
                            <ul class="tab-links">
                                <li class="active"><a href="#tab1">Active Votes</a></li>
                                <li><a href="#tab3">Complete</a></li>
                                <?php  if (is_user_logged_in() || (current_user_can('administrator') )) { ?>
                                <!-- <li><a href="#tab4">Draft</a></li> -->
                                <?php
                                }
                                ?>
                            </ul>
                            <div class="tab-content">
                                <!-- Outputs the tab options in the admin UI. This is a copy of the code that has been moved to utils. -->
                                <div id="tab1" class="tab active">
                                    <div class="table-area">
                                        <table class="custom--table">
                                            <thead>
                                                <tr>
                                                    <th>Proposal Name</th>
                                                    <th>Vote Type</th>
                                                    <th>Voting Stage</th>
                                                    <th>Proposed By</th>
                                                    <th>Seconded By</th>
                                                    <th>Opening Date</th>
                                                    <th>Closing Date</th>
                                                    <th>Visibility</th>
                                                    <!-- <th>Maximum Choices</th> -->
                                                    <th>Active Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                if (!empty($running_votes)) {
                                                    foreach ($running_votes as $option) {
                                                ?>
                                                        <tr>
                                                            <td><?php echo esc_html($option->proposal_name); ?></td>
                                                            <td><?php echo esc_html($option->vote_type); ?></td>
                                                            <td><?php echo esc_html($option->voting_stage); ?></td>
                                                            <td><?php echo esc_html($option->proposed_by); ?></td>
                                                            <td><?php echo esc_html($option->seconded_by); ?></td>
                                                            <td><?php echo esc_html($option->opening_date); ?></td>
                                                            <td><?php echo esc_html($option->closing_date); ?></td>
                                                            <td><?php echo esc_html($option->visibility); ?></td>
                                                            <!-- <td><?php echo esc_html($option->maximum_choices); ?></td> -->
                                                            <td><?php echo esc_attr($option->active_status === 'activeVote' ? 'Active Vote' : 'Inactive Vote'); ?></td>
                                                            <td>
                                                                <?php if ($option->voting_stage == 'autopass' && current_user_can('author')) { ?>
                                                                    <a href="<?php echo esc_url(site_url('/owbn-preview-vote?id=' . $option->id)); ?>" class="edit-icon">
                                                                        View
                                                                    </a>
                                                                <?php } else {
																 	$opening_date_str = strtotime($option->opening_date); // Opening date
																	$closing_date_str = strtotime($option->closing_date); // Closing date

																	if ($option->active_status != 'activeVote' || time() < $opening_date_str || time() > $closing_date_str) {
																		echo 'Polls not active';
																	}else{
																?>
                                                                    <a href="<?php echo esc_url(site_url('/owbn-voting-box?id=' . $option->id)); ?>" class="edit-icon">
                                                                        Perticipate
                                                                    </a>

                                                                <?php } }?>

                                                            </td>
                                                        </tr>
                                                    <?php
                                                    }
                                                } else {
                                                    ?>
                                                    <tr>
                                                        <td colspan="11">No results found.</td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div id="tab3" class="tab">
                                    <div class="table-area complete--tab">
                                        <table class="custom--table">
                                            <thead>
                                                <tr>
                                                    <th>Proposal Name</th>
                                                    <th>Vote Type</th>
                                                    <th>Voting Stage</th>
                                                    <th>Opening Date</th>
                                                    <th>Closing Date</th>
                                                    <th>Result</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if (!empty($completed_votes)) {
                                                    foreach ($completed_votes as $option) {
                                                ?>
                                                        <tr>
                                                            <td><?php echo esc_html($option->proposal_name); ?></td>
                                                            <td><?php echo esc_html($option->vote_type); ?></td>
                                                            <td><?php echo esc_html($option->voting_stage); ?></td>

                                                            <td><?php echo esc_html($option->opening_date); ?></td>
                                                            <td><?php echo esc_html($option->closing_date); ?></td>

                                                            <td>
                                                                <a href="<?php echo esc_url(site_url('/owbn-voting-result?id=' . $option->id)); ?>" class="edit-icon">
                                                                    Show
                                                                </a>

                                                            </td>
                                                        </tr>
                                                    <?php
                                                    }
                                                } else {
                                                    ?>
                                                    <tr>
                                                        <td colspan="11">No results found.</td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php  if (is_user_logged_in() || (current_user_can('administrator') )) { ?>
                                <!-- <div id="tab4" class="tab">
                                    <div class="table-area">
                                        <table class="custom--table">
                                            <thead>
                                                <tr>
                                                    <th>Proposal Name</th>
                                                    <th>Vote Type</th>
                                                    <th>Voting Stage</th>
                                                    <th>Opening Date</th>
                                                    <th>Closing Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if (!empty($draft_votes)) {
                                                    foreach ($draft_votes as $option) {
                                                ?>
                                                        <tr>
                                                            <td><?php echo esc_html($option->proposal_name); ?></td>
                                                            <td><?php echo esc_html($option->vote_type); ?></td>
                                                            <td><?php echo esc_html($option->voting_stage); ?></td>

                                                            <td><?php echo esc_html($option->opening_date); ?></td>
                                                            <td><?php echo esc_html($option->closing_date); ?></td>

                                                            <td>
                                                                <a href="<?php echo esc_url(site_url('/owbn-voting-form?id=' . $option->id)); ?>" class="edit-icon">
                                                                    <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                                </a>

                                                            </td>
                                                        </tr>
                                                    <?php
                                                    }
                                                } else {
                                                    ?>
                                                    <tr>
                                                        <td colspan="11">No results found.</td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div> -->
                                <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <script>
            var phpFilesName = <?php echo $voting_options_json1; ?>;
            var phpFilesName2 = <?php echo $voting_options_json; ?>;
            // console.log(phpFilesName)
            // console.log(phpFilesName2)

            function deleteVote(id) {
                if (confirm('Are you sure you want to delete this vote?')) {
                    // If user confirms deletion, send AJAX request to delete-vote.php
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', '<?php echo esc_url(admin_url('admin-ajax.php')); ?>');
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            // Refresh the page after successful deletion
                            window.location.reload();
                        } else {
                            console.error('Error deleting vote');
                        }
                    };
                    xhr.send('action=delete_vote&id=' + id);
                }
            }
        </script>


        <script>
            jQuery(document).ready(function() {
                function handleTabSwitch(e) {
                    e.preventDefault();
                    var currentAttrValue = jQuery(this).attr('href');
                    jQuery('.tab' + currentAttrValue).fadeIn(400).siblings().hide();
                    jQuery(this).parent('li').addClass('active').siblings().removeClass('active');
                }

                jQuery('.tab-links a').on('click', handleTabSwitch);

                jQuery('#addTab').on('click', function() {
                    var newTabIndex = jQuery('.tab-links li').length + 1;
                    var newTabId = 'tab' + newTabIndex;
                    jQuery('.tab-links').append('<li><a href="#' + newTabId + '">Tab ' + newTabIndex + '</a></li>');
                    jQuery('.tab-content').append('<div id="' + newTabId + '" class="tab"><p>Content for Tab ' +
                        newTabIndex + '</p></div>');
                    jQuery('.tab-links a').off('click').on('click', handleTabSwitch);
                });
            });
        </script>

<?php
        return ob_get_clean();
    } else {
        // User is not logged in, redirect to staff login page
        wp_redirect(site_url('/staff-login'));
        exit;
    }
}
add_shortcode('elections_dashboard', 'elections_dashboard_shortcode');
