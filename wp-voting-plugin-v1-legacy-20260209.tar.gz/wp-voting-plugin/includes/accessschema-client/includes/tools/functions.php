<?php

/** File: includes/tools/functions.php
 * Text Domain: accessschema-client
 * version 1.2.0
 * @author greghacke
 * Function: Tools functions for the AccessSchema client plugin
 */

defined( 'ABSPATH' ) || exit;