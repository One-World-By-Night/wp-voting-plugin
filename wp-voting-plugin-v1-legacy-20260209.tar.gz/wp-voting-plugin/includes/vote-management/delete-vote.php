<?php

/**
 * File: includes/vote-management/delete-vote.php
 * Delete Vote Management Page
 * @version 2.0.0
 */

defined('ABSPATH') || exit;