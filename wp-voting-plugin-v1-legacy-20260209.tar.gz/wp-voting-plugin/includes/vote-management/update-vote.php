<?php

/**
 * File: includes/vote-management/update-vote.php
 * Update Vote Management Page
 * @version 2.0.0
 */

defined('ABSPATH') || exit;