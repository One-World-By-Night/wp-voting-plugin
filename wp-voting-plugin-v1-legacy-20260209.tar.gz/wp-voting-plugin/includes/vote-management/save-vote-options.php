<?php

/**
 * File: includes/vote-management/save-vote-options.php
 * Save Vote Options Management Page
 * @version 2.0.0
 */

defined('ABSPATH') || exit;