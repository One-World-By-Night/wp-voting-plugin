var uploadedFiles = [];
var votingOptions = [];
var multipleChoices = [];
var voteBox = [];
var singleChoice = "";
var userComment = "";
var userId;
var userName;

var customEditor;
