<?php
/**
 * Unified permission system.
 *
 * Permission authority:
 *   - If AccessSchema is configured (mode != 'none'), it is the sole authority
 *     for voter-facing actions. No cached roles = no permissions. No fallback.
 *   - If AccessSchema is NOT configured (mode == 'none'), WordPress capabilities
 *     are the authority.
 *
 * Admin actions (create / manage votes) always require WP `manage_options`
 * because they are WordPress admin-panel operations.
 *
 * Voter-facing actions (cast vote, view results) go through the authority check
 * so that AccessSchema role paths can control per-vote eligibility.
 */

defined( 'ABSPATH' ) || exit;

class WPVP_Permissions {


	/**
	 * Can the user create new votes?
	 */
	public static function can_create_vote( int $user_id = 0 ): bool {
		$user_id = $user_id ? $user_id : get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}

		return user_can( $user_id, 'manage_options' )
			|| user_can( $user_id, 'wpvp_create_votes' );
	}

	/**
	 * Can the user manage (edit / delete / bulk-action) all votes?
	 */
	public static function can_manage_votes( int $user_id = 0 ): bool {
		$user_id = $user_id ? $user_id : get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}

		return user_can( $user_id, 'manage_options' )
			|| user_can( $user_id, 'wpvp_manage_votes' );
	}


	/**
	 * Can the user cast a vote on a specific proposal?
	 *
	 * Checks:
	 *  1. User must be logged in.
	 *  2. Vote must be in 'open' stage, or be a consent item in 'scheduled' stage.
	 *  3. Current time must be within open/close window (if set); a scheduled
	 *     consent item only needs to be before its closing date.
	 *  4. User must not have already voted (unless revoting is allowed).
	 *  5. User must pass the permission check (AccessSchema → WP fallback).
	 */
	public static function can_cast_vote( int $user_id, int $vote_id ): bool {
		if ( ! $user_id ) {
			return false;
		}

		// Admins can always vote.
		if ( user_can( $user_id, 'manage_options' ) ) {
			return true;
		}

		$vote = WPVP_Database::get_vote( $vote_id );
		if ( ! $vote ) {
			return false;
		}

		// Must be open; a consent item also takes objections while scheduled.
		$is_consent_review = 'consent' === $vote->voting_type && 'scheduled' === $vote->voting_stage;
		if ( 'open' !== $vote->voting_stage && ! $is_consent_review ) {
			return false;
		}

		// Date window check; a scheduled consent item takes objections up to its closing date.
		$now = current_time( 'mysql' );
		if ( ! $is_consent_review && $vote->opening_date && $now < $vote->opening_date ) {
			return false;
		}
		if ( $vote->closing_date && $now > $vote->closing_date ) {
			return false;
		}

		// Already voted?
		if ( WPVP_Database::user_has_voted( $user_id, $vote_id ) ) {
			$settings = json_decode( $vote->settings, true );
			$settings = $settings ? $settings : array();
			if ( empty( $settings['allow_revote'] ) ) {
				return false;
			}
		}

		// Voting eligibility check.
		return self::user_can_vote_on( $user_id, $vote );
	}

	/**
	 * Can the user view results for a specific vote?
	 *
	 * Logic:
	 *  - Admins: always yes.
	 *  - Completed/archived votes: anyone who was an eligible voter or who voted.
	 *  - Open votes with "show results before close": eligible voters, and exec and genre coordinators who can view the vote.
	 *  - Otherwise: no.
	 */
	public static function can_view_results( int $user_id, int $vote_id ): bool {
		$vote = WPVP_Database::get_vote( $vote_id );
		if ( ! $vote ) {
			return false;
		}

		// Admins can always view results.
		if ( $user_id && user_can( $user_id, 'manage_options' ) ) {
			return true;
		}

		// Vote creator can always view results.
		if ( $user_id && (int) ( $vote->created_by ?? 0 ) === $user_id ) {
			return true;
		}

		// Public visibility → anyone can view results (including guests).
		if ( 'public' === $vote->visibility ) {
			return true;
		}

		// From here on, user must be logged in.
		if ( ! $user_id ) {
			return false;
		}

		// Private visibility → any logged-in user can view results.
		if ( 'private' === $vote->visibility ) {
			return true;
		}

		// Completed or archived → anyone who voted, is an eligible voter, or is in allowed_roles can see.
		if ( in_array( $vote->voting_stage, array( 'completed', 'archived' ), true ) ) {
			if ( WPVP_Database::user_has_voted( $user_id, $vote_id ) ) {
				return true;
			}
			if ( self::user_can_vote_on( $user_id, $vote ) ) {
				return true;
			}
			return self::can_view_vote( $user_id, $vote );
		}

		// Open vote with "show results before close" — eligible voters, and exec and genre coordinators who can view the vote.
		if ( 'open' === $vote->voting_stage ) {
			$settings = json_decode( $vote->settings, true );
			$settings = $settings ? $settings : array();
			if ( ! empty( $settings['show_results_before_closing'] ) ) {
				if ( self::user_can_vote_on( $user_id, $vote ) ) {
					return true;
				}
				return self::can_view_vote( $user_id, $vote ) && self::check_roles( $user_id, self::live_results_viewer_roles() );
			}
		}

		return false;
	}

	/**
	 * Role patterns, besides eligible voters, that see live results and participation on an open vote they can view.
	 *
	 * @return string[]
	 */
	private static function live_results_viewer_roles(): array {
		return (array) apply_filters( 'wpvp_live_results_viewer_roles', array( 'exec/*/coordinator', 'coordinator/*/coordinator' ) );
	}

	/**
	 * Has the user already voted on this proposal?
	 */
	public static function has_voted( int $user_id, int $vote_id ): bool {
		return WPVP_Database::user_has_voted( $user_id, $vote_id );
	}

	/**
	 * Get all eligible roles for a user to vote on this vote.
	 * Returns array of role paths/names that grant voting access.
	 *
	 * @param int    $user_id User ID.
	 * @param object $vote    Vote object.
	 * @return array Array of role paths. Empty if no eligible roles.
	 */
	public static function get_eligible_voting_roles( int $user_id, object $vote ): array {
		// Public voting = no roles needed.
		if ( 'public' === $vote->voting_eligibility ) {
			return array( 'Public' );
		}

		// Private = any logged-in user (no specific role).
		if ( 'private' === $vote->voting_eligibility ) {
			return array( 'Logged-in User' );
		}

		// Restricted: check voting_roles.
		$voting_roles = json_decode( $vote->voting_roles, true );
		if ( empty( $voting_roles ) ) {
			if ( user_can( $user_id, 'manage_options' ) ) {
				return self::get_admin_roles_with_fallback( $user_id );
			}
			return [];
		}

		$matched = self::get_matching_roles( $user_id, $voting_roles );

		// can_cast_vote() already grants admins permission; the role here is just labeling.
		if ( empty( $matched ) && user_can( $user_id, 'manage_options' ) ) {
			return self::get_admin_roles_with_fallback( $user_id, $voting_roles );
		}

		return $matched;
	}


	/**
	 * Return an admin's real AccessSchema roles (plus 'Administrator' fallback).
	 *
	 * When $vote_roles is provided, filters to user roles sharing a root segment
	 * with the vote's allowed patterns (e.g. exec, coordinator, chronicle) to
	 * avoid offering irrelevant roles like player/approved.
	 *
	 * @param int   $user_id    Admin user ID.
	 * @param array $vote_roles Vote's voting_roles patterns (optional).
	 * @return array
	 */
	private static function get_admin_roles_with_fallback( int $user_id, array $vote_roles = [] ): array {
		$mode = get_option( 'wpvp_accessschema_mode', 'none' );
		if ( 'none' !== $mode ) {
			$cached = get_user_meta( $user_id, 'accessschema_cached_roles', true );
			if ( is_array( $cached ) && ! empty( $cached ) ) {
				$all_roles = self::extract_cached_paths( $cached );
				if ( ! empty( $all_roles ) && ! empty( $vote_roles ) ) {
					// Collect root segments from the vote's allowed patterns.
					$roots = [];
					foreach ( $vote_roles as $vr ) {
						$parts = explode( '/', trim( $vr ) );
						if ( ! empty( $parts[0] ) ) {
							$roots[ strtolower( $parts[0] ) ] = true;
						}
					}
					// Keep only user roles whose root matches.
					$filtered = [];
					foreach ( $all_roles as $role ) {
						$parts = explode( '/', $role );
						if ( isset( $roots[ strtolower( $parts[0] ) ] ) ) {
							$filtered[] = $role;
						}
					}
					if ( ! empty( $filtered ) ) {
						$filtered[] = 'Administrator';
						return $filtered;
					}
				}
				if ( ! empty( $all_roles ) ) {
					$all_roles[] = 'Administrator';
					return $all_roles;
				}
			}
		}
		return [ 'Administrator' ];
	}

	/**
	 * Can the user VIEW this vote?
	 *
	 * Checks visibility + allowed_roles (who can SEE the vote).
	 *
	 * Priority chain:
	 *  1. Public visibility → everyone can view.
	 *  2. Private visibility → any logged-in user can view.
	 *  3. Restricted visibility → check allowed_roles via AccessSchema
	 *     (if configured) or WordPress capabilities (if not).
	 */
	public static function can_view_vote( int $user_id, object $vote ): bool {
		// Admins can always view.
		if ( $user_id && user_can( $user_id, 'manage_options' ) ) {
			return true;
		}

		// Draft votes are only visible to admins (handled above).
		if ( 'draft' === $vote->voting_stage ) {
			return false;
		}

		// Public votes are visible to everyone.
		if ( 'public' === $vote->visibility ) {
			return true;
		}

		// Private = any logged-in user can view.
		if ( 'private' === $vote->visibility ) {
			return $user_id > 0;
		}

		// Restricted: check allowed_roles.
		$allowed_roles = json_decode( $vote->allowed_roles, true );
		if ( empty( $allowed_roles ) ) {
			return false;
		}

		return self::check_roles( $user_id, $allowed_roles );
	}

	/**
	 * Can the user VOTE on this vote?
	 *
	 * Checks voting_eligibility + voting_roles (who can CAST a ballot).
	 *
	 * Priority chain:
	 *  1. Public voting → anyone can vote (even non-logged-in if allowed).
	 *  2. Private voting → any logged-in user can vote.
	 *  3. Restricted voting → check voting_roles via AccessSchema
	 *     (if configured) or WordPress capabilities (if not).
	 */
	private static function user_can_vote_on( int $user_id, object $vote ): bool {
		// Public voting is open to everyone.
		if ( 'public' === $vote->voting_eligibility ) {
			return true;
		}

		// Private = any logged-in user can vote.
		if ( 'private' === $vote->voting_eligibility ) {
			return $user_id > 0;
		}

		// Restricted: check voting_roles.
		$voting_roles = json_decode( $vote->voting_roles, true );
		if ( empty( $voting_roles ) ) {
			return false;
		}

		return self::check_roles( $user_id, $voting_roles );
	}

	/**
	 * Check if user has any of the specified roles.
	 *
	 * If AccessSchema is configured, it is the sole authority (no WP fallback).
	 * If AccessSchema is NOT configured, checks WordPress roles/capabilities.
	 *
	 * @param int   $user_id User ID.
	 * @param array $roles   Role paths, slugs, or capabilities.
	 * @return bool
	 */
	private static function check_roles( int $user_id, array $roles ): bool {
		if ( empty( $roles ) ) {
			return false;
		}

		// Try AccessSchema first.
		$asc_result = self::check_accessschema( $user_id, $roles );
		if ( null !== $asc_result ) {
			return $asc_result; // AccessSchema gave a definitive answer.
		}

		// AccessSchema not configured — WordPress roles are the authority.
		return self::check_wp_roles( $user_id, $roles );
	}

	/**
	 * Check AccessSchema roles for the user.
	 *
	 * Supports wildcard patterns in role paths:
	 *  - Single wildcard (*) matches one path segment, e.g. "Chronicle/{*}/CM"
	 *  - Double wildcard (**) matches one or more segments, e.g. "Players/{**}"
	 *
	 * Wildcard patterns are expanded against cached roles from the
	 * wpvp_accessschema_roles transient, then each concrete path is
	 * checked via the API (short-circuits on first match).
	 *
	 * @return bool|null  true/false if AccessSchema answered, null if unavailable.
	 */
	private static function check_accessschema( int $user_id, array $role_paths ): ?bool {
		$mode = get_option( 'wpvp_accessschema_mode', 'none' );
		if ( 'none' === $mode ) {
			return null; // Not configured.
		}

		// Visitors who are not logged in hold no roles.
		if ( ! $user_id ) {
			return false;
		}

		$user = get_userdata( $user_id );
		if ( ! $user || empty( $user->user_email ) ) {
			error_log( sprintf(
				'WPVP: AccessSchema mode=%s, user %d not found or has no email — denied.',
				$mode, $user_id
			) );
			return false;
		}

		// Get user's cached roles from shared AccessSchema cache key.
		// No cached roles = no permissions. ASC is the sole authority.
		$user_roles = get_user_meta( $user_id, 'accessschema_cached_roles', true );
		if ( ! is_array( $user_roles ) || empty( $user_roles ) ) {
			return false;
		}

		// Check each allowed role path — user needs to match at least one.
		foreach ( $role_paths as $role_path ) {
			$role_path = sanitize_text_field( $role_path );
			if ( empty( $role_path ) ) {
				continue;
			}

			// Wildcard pattern - match directly against user's cached roles.
			if ( false !== strpos( $role_path, '*' ) ) {
				$regex = self::wildcard_to_regex( $role_path );
				foreach ( $user_roles as $user_role ) {
					if ( preg_match( $regex, $user_role ) ) {
						return true;
					}
				}
				continue;
			}

			// Literal path — check against user's cached roles (with children support).
			if ( self::user_has_cached_role( $user_roles, $role_path, true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if user has a cached role, optionally including child roles.
	 *
	 * @param array  $user_roles      User's cached role paths.
	 * @param string $target_role     Role path to check for.
	 * @param bool   $include_children Whether to match child roles.
	 * @return bool
	 */
	private static function user_has_cached_role( array $user_roles, string $target_role, bool $include_children = false ): bool {
		// Direct match.
		if ( in_array( $target_role, $user_roles, true ) ) {
			return true;
		}

		// Check for child roles (user has target_role/something).
		if ( $include_children ) {
			$target_prefix = $target_role . '/';
			foreach ( $user_roles as $user_role ) {
				if ( 0 === strpos( $user_role, $target_prefix ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Get all roles from the allowed list that the user has.
	 * Similar to check_roles() but returns matched roles instead of boolean.
	 *
	 * @param int   $user_id User ID.
	 * @param array $roles   Allowed role paths.
	 * @return array Matched role paths.
	 */
	private static function get_matching_roles( int $user_id, array $roles ): array {
		if ( empty( $roles ) ) {
			return array();
		}

		// Try AccessSchema first.
		$asc_matches = self::get_accessschema_matches( $user_id, $roles );
		if ( null !== $asc_matches ) {
			// AccessSchema is available - return only AccessSchema matches.
			return $asc_matches;
		}

		// AccessSchema not configured — WordPress roles are the authority.
		return self::get_wp_role_matches( $user_id, $roles );
	}

	/**
	 * Get AccessSchema roles that match for this user.
	 *
	 * @param int   $user_id    User ID.
	 * @param array $role_paths Allowed role paths.
	 * @return array|null Array of matched role paths, or null if AccessSchema unavailable.
	 */
	private static function get_accessschema_matches( int $user_id, array $role_paths ): ?array {
		$mode = get_option( 'wpvp_accessschema_mode', 'none' );
		if ( 'none' === $mode ) {
			return null;
		}

		$user = get_userdata( $user_id );
		if ( ! $user || empty( $user->user_email ) ) {
			error_log( sprintf(
				'WPVP: AccessSchema mode=%s, user %d not found or has no email in role matching — denied.',
				$mode, $user_id
			) );
			return array();
		}

		// No cached roles = no permissions. ASC is the sole authority.
		$user_roles = get_user_meta( $user_id, 'accessschema_cached_roles', true );
		if ( ! is_array( $user_roles ) || empty( $user_roles ) ) {
			return array();
		}

		$matches = array();

		foreach ( $role_paths as $role_path ) {
			$role_path = sanitize_text_field( $role_path );
			if ( empty( $role_path ) ) {
				continue;
			}

			// Wildcard pattern - match directly against user's cached roles.
			if ( false !== strpos( $role_path, '*' ) ) {
				$regex = self::wildcard_to_regex( $role_path );
				foreach ( $user_roles as $user_role ) {
					if ( preg_match( $regex, $user_role ) ) {
						$matches[] = $user_role;
					}
				}
				continue;
			}

			// Literal path.
			if ( self::user_has_cached_role( $user_roles, $role_path, true ) ) {
				// Find the exact role user has (may be child role).
				if ( in_array( $role_path, $user_roles, true ) ) {
					$matches[] = $role_path;
				} else {
					// User has child role.
					$target_prefix = $role_path . '/';
					foreach ( $user_roles as $user_role ) {
						if ( 0 === strpos( $user_role, $target_prefix ) ) {
							$matches[] = $user_role;
						}
					}
				}
			}
		}

		return $matches;
	}

	/**
	 * Get WordPress roles that match for this user.
	 *
	 * @param int   $user_id User ID.
	 * @param array $roles   Allowed roles/capabilities.
	 * @return array Matched role names.
	 */
	private static function get_wp_role_matches( int $user_id, array $roles ): array {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return array();
		}

		$matches = array();

		foreach ( $roles as $role_or_cap ) {
			$role_or_cap = sanitize_text_field( $role_or_cap );

			// Skip wildcard patterns.
			if ( false !== strpos( $role_or_cap, '*' ) ) {
				continue;
			}

			// Check as WP role.
			if ( in_array( $role_or_cap, $user->roles, true ) ) {
				$matches[] = ucfirst( $role_or_cap );
			} elseif ( user_can( $user_id, $role_or_cap ) ) {
				// Check as WP capability.
				$matches[] = ucfirst( $role_or_cap );
			}
		}

		return $matches;
	}

	/**
	 * Fallback: check if the user has any of the specified WordPress roles.
	 *
	 * The allowed_roles array may contain WP role slugs (subscriber, editor, etc.)
	 * or WP capabilities. Entries containing wildcards are skipped (not applicable
	 * to flat WP roles).
	 */
	private static function check_wp_roles( int $user_id, array $roles ): bool {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		foreach ( $roles as $role_or_cap ) {
			$role_or_cap = sanitize_text_field( $role_or_cap );

			// Skip wildcard patterns — they only apply to AccessSchema paths.
			if ( false !== strpos( $role_or_cap, '*' ) ) {
				continue;
			}

			// Check as a WP role first.
			if ( in_array( $role_or_cap, $user->roles, true ) ) {
				return true;
			}

			// Check as a WP capability.
			if ( user_can( $user_id, $role_or_cap ) ) {
				return true;
			}
		}

		return false;
	}


	/**
	 * Expand a wildcard role path pattern against cached AccessSchema roles.
	 *
	 * @param string $pattern Pattern with * and/or ** segments.
	 * @return string[] Matching concrete role paths.
	 */
	private static function expand_wildcard_pattern( string $pattern ): array {
		$cached = get_transient( 'wpvp_accessschema_roles' );
		if ( empty( $cached ) || ! is_array( $cached ) ) {
			return array();
		}

		$all_paths = self::extract_cached_paths( $cached );
		$regex     = self::wildcard_to_regex( $pattern );
		$matches   = array();

		foreach ( $all_paths as $path ) {
			if ( preg_match( $regex, $path ) ) {
				$matches[] = $path;
			}
		}

		return $matches;
	}

	/**
	 * Convert a role path pattern to a regex.
	 *
	 * Supported wildcards:
	 *   *  → matches exactly one path segment (no slashes)
	 *  ** → matches one or more path segments
	 *
	 * Matching is case-insensitive.
	 *
	 * @param string $pattern e.g. "Chronicle/ * /CM" or "Players/ **"
	 * @return string Regex pattern.
	 */
	private static function wildcard_to_regex( string $pattern ): string {
		$segments    = explode( '/', $pattern );
		$regex_parts = array();

		foreach ( $segments as $seg ) {
			$seg = trim( $seg );
			if ( '**' === $seg ) {
				$regex_parts[] = '.+';
			} elseif ( '*' === $seg ) {
				$regex_parts[] = '[^/]+';
			} else {
				$regex_parts[] = preg_quote( $seg, '#' );
			}
		}

		return '#^' . implode( '/', $regex_parts ) . '$#i';
	}

	/**
	 * Extract flat role path strings from the cached AccessSchema transient.
	 *
	 * The transient may be a flat array of strings, an array of objects
	 * with 'path' or 'name' keys, or a structure with a 'roles' wrapper.
	 *
	 * @param array $cached Raw transient data.
	 * @return string[]
	 */
	/**
	 * Public accessor for extracting role paths from cached data.
	 */
	public static function extract_role_paths( array $cached ): array {
		return self::extract_cached_paths( $cached );
	}


	/**
	 * Check if a user can see a ballot via additional viewer patterns.
	 *
	 * The * wildcard in viewer patterns binds to the same-position segment
	 * from the ballot's voting_role. This ensures slug-level matching:
	 * e.g., pattern "chronicle/{wildcard}/hst" + ballot role "chronicle/kony/cm"
	 * resolves to "chronicle/kony/hst" -- user must have that exact role.
	 *
	 * @param int    $user_id                    User to check.
	 * @param string $ballot_voting_role         The voting_role from the ballot.
	 * @param array  $additional_viewer_patterns Patterns like ['chronicle/{wildcard}/hst'].
	 * @return bool
	 */
	public static function matches_additional_viewers( int $user_id, string $ballot_voting_role, array $additional_viewer_patterns ): bool {
		if ( empty( $additional_viewer_patterns ) || empty( $ballot_voting_role ) ) {
			return false;
		}

		// Get the user's roles (AccessSchema first, then WordPress fallback).
		$user_roles = self::get_user_all_roles( $user_id );
		if ( empty( $user_roles ) ) {
			return false;
		}

		$ballot_segments = explode( '/', $ballot_voting_role );

		foreach ( $additional_viewer_patterns as $pattern ) {
			$pattern = trim( $pattern );
			if ( empty( $pattern ) ) {
				continue;
			}

			$pattern_segments  = explode( '/', $pattern );
			$resolved_segments = array();
			$valid             = true;

			foreach ( $pattern_segments as $i => $seg ) {
				$seg = trim( $seg );
				if ( '*' === $seg ) {
					// Bind wildcard to same-position segment from ballot's voting_role.
					if ( ! isset( $ballot_segments[ $i ] ) ) {
						$valid = false;
						break;
					}
					$resolved_segments[] = $ballot_segments[ $i ];
				} else {
					$resolved_segments[] = $seg;
				}
			}

			if ( ! $valid ) {
				continue;
			}

			$resolved_role = implode( '/', $resolved_segments );

			// Check if user has this resolved role (exact or child match, case-insensitive).
			if ( self::user_has_cached_role( $user_roles, $resolved_role, true ) ) {
				return true;
			}

			// Case-insensitive fallback for exact match (user_has_cached_role is case-sensitive).
			foreach ( $user_roles as $user_role ) {
				if ( 0 === strcasecmp( $user_role, $resolved_role ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Get all roles for a user (AccessSchema cached roles or WordPress roles).
	 *
	 * @param int $user_id User ID.
	 * @return string[] Array of role path strings.
	 */
	private static function get_user_all_roles( int $user_id ): array {
		$mode = get_option( 'wpvp_accessschema_mode', 'none' );

		if ( 'none' !== $mode ) {
			// ASC is the sole authority. No cached roles = no roles.
			$user_roles = get_user_meta( $user_id, 'accessschema_cached_roles', true );
			if ( is_array( $user_roles ) && ! empty( $user_roles ) ) {
				return self::extract_cached_paths( $user_roles );
			}
			return array();
		}

		// ASC not configured — WordPress roles are the authority.
		$user = get_userdata( $user_id );
		if ( $user && ! empty( $user->roles ) ) {
			return array_values( $user->roles );
		}

		return array();
	}

	private static function extract_cached_paths( array $cached ): array {
		// If the data has a 'roles' key, unwrap it.
		if ( isset( $cached['roles'] ) && is_array( $cached['roles'] ) ) {
			$cached = $cached['roles'];
		}

		$paths = array();
		foreach ( $cached as $entry ) {
			if ( is_string( $entry ) ) {
				$paths[] = $entry;
			} elseif ( is_array( $entry ) && isset( $entry['path'] ) ) {
				$paths[] = $entry['path'];
			} elseif ( is_array( $entry ) && isset( $entry['name'] ) ) {
				$paths[] = $entry['name'];
			}
		}

		return $paths;
	}
}
