<?php

die("You Don't wanna be here! Go back");