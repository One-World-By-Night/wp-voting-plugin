<?php
/**
 * Elementor Widget: Vote List
 *
 * Displays a filterable, styled table of votes with extensive
 * Elementor controls for content and styling.
 *
 * @package WP_Voting_Plugin
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

class WPVP_Elementor_Vote_List_Widget extends \Elementor\Widget_Base {

	public function get_name(): string {
		return 'wpvp_vote_list';
	}

	public function get_title(): string {
		return __( 'OWBN — Vote List', 'wp-voting-plugin' );
	}

	public function get_icon(): string {
		return 'eicon-bullet-list';
	}

	public function get_categories(): array {
		return array( 'wpvp-voting', 'general' );
	}

	public function get_keywords(): array {
		return array( 'vote', 'voting', 'poll', 'list', 'wpvp', 'owbn', 'ballot' );
	}

	public function get_style_depends(): array {
		return array( 'wpvp-public' );
	}

	public function get_script_depends(): array {
		return array( 'wpvp-public' );
	}

	/*
	|--------------------------------------------------------------------------
	| Controls
	|--------------------------------------------------------------------------
	*/

	protected function register_controls(): void {
		$this->register_content_controls();
		$this->register_style_table_controls();
		$this->register_style_header_controls();
		$this->register_style_row_controls();
		$this->register_style_badge_controls();
		$this->register_style_button_controls();
	}

	/**
	 * Content tab controls.
	 */
	private function register_content_controls(): void {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => __( 'Content', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'status',
			array(
				'label'   => __( 'Status Filter', 'wp-voting-plugin' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'open',
				'options' => array(
					'all'                       => __( 'All Statuses', 'wp-voting-plugin' ),
					'open'                      => __( 'Open', 'wp-voting-plugin' ),
					'closed'                    => __( 'Closed', 'wp-voting-plugin' ),
					'completed'                 => __( 'Completed', 'wp-voting-plugin' ),
					'archived'                  => __( 'Archived', 'wp-voting-plugin' ),
					'closed,completed'          => __( 'Closed + Completed', 'wp-voting-plugin' ),
					'closed,completed,archived' => __( 'Closed + Completed + Archived', 'wp-voting-plugin' ),
				),
			)
		);

		$this->add_control(
			'limit',
			array(
				'label'   => __( 'Number of Votes', 'wp-voting-plugin' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 20,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			)
		);

		$this->add_control(
			'show_dates',
			array(
				'label'        => __( 'Show Date Columns', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_status_column',
			array(
				'label'        => __( 'Show Status Column', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_action_column',
			array(
				'label'        => __( 'Show Action Column', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'empty_message',
			array(
				'label'       => __( 'Empty Message', 'wp-voting-plugin' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => __( 'No votes found.', 'wp-voting-plugin' ),
				'placeholder' => __( 'No votes found.', 'wp-voting-plugin' ),
				'label_block' => true,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Table container.
	 */
	private function register_style_table_controls(): void {
		$this->start_controls_section(
			'section_style_table',
			array(
				'label' => __( 'Table Container', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'table_bg_color',
			array(
				'label'     => __( 'Background Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'table_border',
				'label'    => __( 'Border', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-table',
			)
		);

		$this->add_responsive_control(
			'table_border_radius',
			array(
				'label'      => __( 'Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-vote-table' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'table_shadow',
				'label'    => __( 'Box Shadow', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-table',
			)
		);

		$this->add_control(
			'empty_text_color',
			array(
				'label'     => __( 'Empty Message Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-list__empty' => 'color: {{VALUE}};',
				),
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'empty_text_typography',
				'label'    => __( 'Empty Message Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-list__empty',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Table header.
	 */
	private function register_style_header_controls(): void {
		$this->start_controls_section(
			'section_style_header',
			array(
				'label' => __( 'Table Header', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'header_bg_color',
			array(
				'label'     => __( 'Background Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table thead' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'header_text_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table th' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'header_typography',
				'label'    => __( 'Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-table th',
			)
		);

		$this->add_responsive_control(
			'header_padding',
			array(
				'label'      => __( 'Padding', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-vote-table th' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'header_border_color',
			array(
				'label'     => __( 'Bottom Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table th' => 'border-bottom-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Table rows.
	 */
	private function register_style_row_controls(): void {
		$this->start_controls_section(
			'section_style_rows',
			array(
				'label' => __( 'Table Rows', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'row_colors' );

		$this->start_controls_tab(
			'row_normal',
			array( 'label' => __( 'Normal', 'wp-voting-plugin' ) )
		);

		$this->add_control(
			'row_bg_color',
			array(
				'label'     => __( 'Background Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table tbody tr' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'row_text_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table td' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'row_hover',
			array( 'label' => __( 'Hover', 'wp-voting-plugin' ) )
		);

		$this->add_control(
			'row_hover_bg',
			array(
				'label'     => __( 'Background Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table tbody tr:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'row_hover_text_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table tbody tr:hover td' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'row_typography',
				'label'     => __( 'Typography', 'wp-voting-plugin' ),
				'selector'  => '{{WRAPPER}} .wpvp-vote-table td',
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'row_padding',
			array(
				'label'      => __( 'Cell Padding', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-vote-table td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'row_border_color',
			array(
				'label'     => __( 'Row Divider Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table tbody tr' => 'border-bottom-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'heading_title_style',
			array(
				'label'     => __( 'Title Link', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'title_link_color',
			array(
				'label'     => __( 'Link Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table__link' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'title_link_hover_color',
			array(
				'label'     => __( 'Link Hover Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table__link:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => __( 'Title Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-table__title',
			)
		);

		$this->add_control(
			'heading_date_style',
			array(
				'label'     => __( 'Date Columns', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'date_text_color',
			array(
				'label'     => __( 'Date Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-table__date' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'date_typography',
				'label'    => __( 'Date Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-table__date',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Badges.
	 */
	private function register_style_badge_controls(): void {
		$this->start_controls_section(
			'section_style_badges',
			array(
				'label' => __( 'Status Badges', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'badge_typography',
				'label'    => __( 'Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-badge',
			)
		);

		$this->add_responsive_control(
			'badge_padding',
			array(
				'label'      => __( 'Padding', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'badge_border_radius',
			array(
				'label'      => __( 'Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-badge' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		// Per-status badge colors.
		$badge_statuses = array(
			'open'      => __( 'Open', 'wp-voting-plugin' ),
			'closed'    => __( 'Closed', 'wp-voting-plugin' ),
			'completed' => __( 'Completed', 'wp-voting-plugin' ),
			'archived'  => __( 'Archived', 'wp-voting-plugin' ),
			'draft'     => __( 'Draft', 'wp-voting-plugin' ),
		);

		foreach ( $badge_statuses as $slug => $label ) {
			$this->add_control(
				'badge_heading_' . $slug,
				array(
					'label'     => $label,
					'type'      => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_control(
				'badge_bg_' . $slug,
				array(
					'label'     => __( 'Background', 'wp-voting-plugin' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .wpvp-badge--' . $slug => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'badge_color_' . $slug,
				array(
					'label'     => __( 'Text Color', 'wp-voting-plugin' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .wpvp-badge--' . $slug => 'color: {{VALUE}};',
					),
				)
			);
		}

		$this->end_controls_section();
	}

	/**
	 * Style: Buttons.
	 */
	private function register_style_button_controls(): void {
		$this->start_controls_section(
			'section_style_buttons',
			array(
				'label' => __( 'Action Buttons', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'btn_typography',
				'label'    => __( 'Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-btn',
			)
		);

		$this->add_responsive_control(
			'btn_border_radius',
			array(
				'label'      => __( 'Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-btn' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'btn_padding',
			array(
				'label'      => __( 'Padding', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Primary button.
		$this->add_control(
			'heading_btn_primary',
			array(
				'label'     => __( 'Primary Button (Vote)', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->start_controls_tabs( 'btn_primary_colors' );

		$this->start_controls_tab( 'btn_primary_normal', array( 'label' => __( 'Normal', 'wp-voting-plugin' ) ) );
		$this->add_control( 'btn_primary_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-btn--primary' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ),
		) );
		$this->add_control( 'btn_primary_color', array(
			'label'     => __( 'Text Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-btn--primary' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_tab();

		$this->start_controls_tab( 'btn_primary_hover', array( 'label' => __( 'Hover', 'wp-voting-plugin' ) ) );
		$this->add_control( 'btn_primary_hover_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-btn--primary:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ),
		) );
		$this->add_control( 'btn_primary_hover_color', array(
			'label'     => __( 'Text Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-btn--primary:hover' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		// Secondary button.
		$this->add_control(
			'heading_btn_secondary',
			array(
				'label'     => __( 'Secondary Button (View)', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->start_controls_tabs( 'btn_secondary_colors' );

		$this->start_controls_tab( 'btn_secondary_normal', array( 'label' => __( 'Normal', 'wp-voting-plugin' ) ) );
		$this->add_control( 'btn_secondary_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-btn--secondary' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ),
		) );
		$this->add_control( 'btn_secondary_color', array(
			'label'     => __( 'Text Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-btn--secondary' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_tab();

		$this->start_controls_tab( 'btn_secondary_hover', array( 'label' => __( 'Hover', 'wp-voting-plugin' ) ) );
		$this->add_control( 'btn_secondary_hover_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-btn--secondary:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ),
		) );
		$this->add_control( 'btn_secondary_hover_color', array(
			'label'     => __( 'Text Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-btn--secondary:hover' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/*
	|--------------------------------------------------------------------------
	| Render
	|--------------------------------------------------------------------------
	*/

	protected function render(): void {
		$settings = $this->get_settings_for_display();

		$render_settings = array(
			'status'             => $settings['status'] ?? 'open',
			'limit'              => intval( $settings['limit'] ?? 20 ),
			'show_dates'         => ( $settings['show_dates'] ?? 'yes' ) === 'yes',
			'show_status_column' => ( $settings['show_status_column'] ?? 'yes' ) === 'yes',
			'show_action_column' => ( $settings['show_action_column'] ?? 'yes' ) === 'yes',
			'empty_message'      => $settings['empty_message'] ?? '',
		);

		echo WPVP_Renderer::render_vote_list( $render_settings );
	}
}
