<?php
/**
 * Elementor widgets loader.
 *
 * Registers widget category and loads individual widget classes
 * when Elementor is active.
 *
 * @package WP_Voting_Plugin
 */

defined( 'ABSPATH' ) || exit;

class WPVP_Elementor_Loader {

	/**
	 * Boot the Elementor integration.
	 *
	 * Handles both load orderings: our plugin before Elementor
	 * (hook into elementor/loaded) and Elementor before us (direct setup).
	 */
	public static function init(): void {
		if ( did_action( 'elementor/loaded' ) ) {
			self::register_hooks();
		} else {
			add_action( 'elementor/loaded', array( __CLASS__, 'register_hooks' ) );
		}
	}

	/**
	 * Register Elementor hooks for category and widgets.
	 */
	public static function register_hooks(): void {
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widgets' ) );
	}

	/**
	 * Register the WPVP Voting widget category.
	 */
	public static function register_category( $elements_manager ): void {
		$elements_manager->add_category(
			'wpvp-voting',
			array(
				'title' => __( 'WPVP Voting', 'wp-voting-plugin' ),
				'icon'  => 'eicon-check-circle',
			)
		);
	}

	/**
	 * Register all Elementor widgets.
	 */
	public static function register_widgets( $widgets_manager ): void {
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		require_once WPVP_PLUGIN_DIR . 'includes/elementor/class-vote-list-widget.php';
		require_once WPVP_PLUGIN_DIR . 'includes/elementor/class-vote-detail-widget.php';
		require_once WPVP_PLUGIN_DIR . 'includes/elementor/class-results-widget.php';

		$widgets_manager->register( new WPVP_Elementor_Vote_List_Widget() );
		$widgets_manager->register( new WPVP_Elementor_Vote_Detail_Widget() );
		$widgets_manager->register( new WPVP_Elementor_Vote_Results_Widget() );
	}
}
