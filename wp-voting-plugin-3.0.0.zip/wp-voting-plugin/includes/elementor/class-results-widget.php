<?php
/**
 * Elementor Widget: Vote Results
 *
 * Displays computed results for a vote with winner banners, tables,
 * bar charts, round details, and voter lists. Extensively styleable.
 *
 * @package WP_Voting_Plugin
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

class WPVP_Elementor_Vote_Results_Widget extends \Elementor\Widget_Base {

	public function get_name(): string {
		return 'wpvp_results';
	}

	public function get_title(): string {
		return __( 'OWBN — Vote Results', 'wp-voting-plugin' );
	}

	public function get_icon(): string {
		return 'eicon-bar-chart';
	}

	public function get_categories(): array {
		return array( 'wpvp-voting', 'general' );
	}

	public function get_keywords(): array {
		return array( 'vote', 'results', 'chart', 'poll', 'wpvp', 'owbn', 'winner' );
	}

	public function get_style_depends(): array {
		return array( 'wpvp-public' );
	}

	public function get_script_depends(): array {
		return array( 'wpvp-public' );
	}

	/*
	|--------------------------------------------------------------------------
	| Controls
	|--------------------------------------------------------------------------
	*/

	protected function register_controls(): void {
		$this->register_content_controls();
		$this->register_style_banner_controls();
		$this->register_style_table_controls();
		$this->register_style_bar_controls();
		$this->register_style_rounds_controls();
		$this->register_style_voter_controls();
		$this->register_style_meta_controls();
	}

	/**
	 * Content tab.
	 */
	private function register_content_controls(): void {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => __( 'Content', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'vote_id',
			array(
				'label'       => __( 'Vote', 'wp-voting-plugin' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => WPVP_Renderer::get_vote_options(),
				'default'     => '0',
				'label_block' => true,
				'description' => __( 'Select a vote or use "Dynamic from URL" for ?wpvp_vote= parameter. Leave on dynamic to show a results list.', 'wp-voting-plugin' ),
			)
		);

		$this->add_control(
			'show_title',
			array(
				'label'        => __( 'Show Title & Stage Badge', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_winner_banner',
			array(
				'label'        => __( 'Show Winner Banner', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_rounds',
			array(
				'label'        => __( 'Show Round Details (RCV/STV)', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_csv_export',
			array(
				'label'        => __( 'Show CSV Export (Admin)', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_event_log',
			array(
				'label'        => __( 'Show Processing Log (Admin)', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_voter_list',
			array(
				'label'        => __( 'Show Voter List', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Winner / Tie banner.
	 */
	private function register_style_banner_controls(): void {
		$this->start_controls_section(
			'section_style_banner',
			array(
				'label' => __( 'Winner / Tie Banner', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Winner banner.
		$this->add_control(
			'heading_winner_banner',
			array(
				'label' => __( 'Winner Banner', 'wp-voting-plugin' ),
				'type'  => \Elementor\Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'winner_banner_bg',
			array(
				'label'     => __( 'Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__banner--winner' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'winner_banner_border_color',
			array(
				'label'     => __( 'Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__banner--winner' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'winner_banner_text_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__banner--winner, {{WRAPPER}} .wpvp-results__banner--winner strong, {{WRAPPER}} .wpvp-results__banner--winner span' => 'color: {{VALUE}};',
				),
			)
		);

		// Tie banner.
		$this->add_control(
			'heading_tie_banner',
			array(
				'label'     => __( 'Tie Banner', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'tie_banner_bg',
			array(
				'label'     => __( 'Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__banner--tie' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'tie_banner_border_color',
			array(
				'label'     => __( 'Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__banner--tie' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'tie_banner_text_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__banner--tie, {{WRAPPER}} .wpvp-results__banner--tie strong, {{WRAPPER}} .wpvp-results__banner--tie span' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'banner_label_typography',
				'label'     => __( 'Label Typography', 'wp-voting-plugin' ),
				'selector'  => '{{WRAPPER}} .wpvp-results__banner strong',
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'banner_value_typography',
				'label'    => __( 'Winner Name Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-results__banner span',
			)
		);

		$this->add_responsive_control(
			'banner_padding',
			array(
				'label'      => __( 'Padding', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-results__banner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'banner_border_radius',
			array(
				'label'      => __( 'Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-results__banner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Results table.
	 */
	private function register_style_table_controls(): void {
		$this->start_controls_section(
			'section_style_table',
			array(
				'label' => __( 'Results Table', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'results_header_bg',
			array(
				'label'     => __( 'Header Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__table th' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'results_header_color',
			array(
				'label'     => __( 'Header Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__table th' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'results_header_typography',
				'label'    => __( 'Header Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-results__table th',
			)
		);

		$this->add_control(
			'results_row_color',
			array(
				'label'     => __( 'Row Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__table td' => 'color: {{VALUE}};',
				),
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'results_row_typography',
				'label'    => __( 'Row Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-results__table td',
			)
		);

		$this->add_control(
			'results_border_color',
			array(
				'label'     => __( 'Cell Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__table th, {{WRAPPER}} .wpvp-results__table td' => 'border-bottom-color: {{VALUE}};',
				),
			)
		);

		// Winner row highlight.
		$this->add_control(
			'heading_winner_row',
			array(
				'label'     => __( 'Winner Row', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'winner_row_bg',
			array(
				'label'     => __( 'Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__row--winner' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'winner_badge_bg',
			array(
				'label'     => __( 'Winner Badge Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__winner-badge' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'winner_badge_color',
			array(
				'label'     => __( 'Winner Badge Text', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__winner-badge' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Bar charts.
	 */
	private function register_style_bar_controls(): void {
		$this->start_controls_section(
			'section_style_bars',
			array(
				'label' => __( 'Vote Bars', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'bar_bg',
			array(
				'label'     => __( 'Track Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-bar' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bar_fill_color',
			array(
				'label'     => __( 'Fill Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-bar__fill' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bar_winner_fill_color',
			array(
				'label'     => __( 'Winner Fill Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-bar__fill--winner' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'bar_height',
			array(
				'label'      => __( 'Bar Height', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 8, 'max' => 40 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-bar'       => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .wpvp-bar__fill'  => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'bar_border_radius',
			array(
				'label'      => __( 'Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-bar, {{WRAPPER}} .wpvp-bar__fill' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Round details.
	 */
	private function register_style_rounds_controls(): void {
		$this->start_controls_section(
			'section_style_rounds',
			array(
				'label' => __( 'Round Details', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'round_bg',
			array(
				'label'     => __( 'Round Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-round' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'round_border_radius',
			array(
				'label'      => __( 'Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-round' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'round_padding',
			array(
				'label'      => __( 'Padding', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-round' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'round_heading_color',
			array(
				'label'     => __( 'Round Heading Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-round h5' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'eliminated_color',
			array(
				'label'     => __( 'Eliminated Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-round__eliminated' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Voter entries.
	 */
	private function register_style_voter_controls(): void {
		$this->start_controls_section(
			'section_style_voters',
			array(
				'label' => __( 'Voter List', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'voter_entry_bg',
			array(
				'label'     => __( 'Entry Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-voter-entry' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'voter_entry_border_color',
			array(
				'label'     => __( 'Left Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-voter-entry' => 'border-left-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'voter_name_color',
			array(
				'label'     => __( 'Name Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-voter-entry__name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'voter_role_color',
			array(
				'label'     => __( 'Role Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-voter-entry__role' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'voter_choice_color',
			array(
				'label'     => __( 'Choice Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-voter-entry__choice' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'voter_comment_color',
			array(
				'label'     => __( 'Comment Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-voter-entry__comment' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'voter_typography',
				'label'     => __( 'Entry Typography', 'wp-voting-plugin' ),
				'selector'  => '{{WRAPPER}} .wpvp-voter-entry__main',
				'separator' => 'before',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Meta section.
	 */
	private function register_style_meta_controls(): void {
		$this->start_controls_section(
			'section_style_meta',
			array(
				'label' => __( 'Results Meta', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'meta_text_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__meta' => 'color: {{VALUE}};',
					'{{WRAPPER}} .wpvp-results__meta p' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'meta_typography',
				'label'    => __( 'Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-results__meta',
			)
		);

		$this->add_control(
			'meta_border_color',
			array(
				'label'     => __( 'Top Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__meta' => 'border-top-color: {{VALUE}};',
				),
			)
		);

		// Consent results.
		$this->add_control(
			'heading_consent_style',
			array(
				'label'     => __( 'Consent Results', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'consent_passed_bg',
			array(
				'label'     => __( 'Passed Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__consent-status--passed' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'consent_passed_border',
			array(
				'label'     => __( 'Passed Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__consent-status--passed' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'consent_passed_color',
			array(
				'label'     => __( 'Passed Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__consent-status--passed, {{WRAPPER}} .wpvp-results__consent-status--passed strong, {{WRAPPER}} .wpvp-results__consent-status--passed p' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'consent_objected_bg',
			array(
				'label'     => __( 'Objected Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__consent-status--objected' => 'background-color: {{VALUE}};',
				),
				'separator' => 'before',
			)
		);

		$this->add_control(
			'consent_objected_border',
			array(
				'label'     => __( 'Objected Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__consent-status--objected' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'consent_objected_color',
			array(
				'label'     => __( 'Objected Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__consent-status--objected, {{WRAPPER}} .wpvp-results__consent-status--objected strong, {{WRAPPER}} .wpvp-results__consent-status--objected p' => 'color: {{VALUE}};',
				),
			)
		);

		// Processing log.
		$this->add_control(
			'heading_log_style',
			array(
				'label'     => __( 'Processing Log', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'log_bg',
			array(
				'label'     => __( 'Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__log' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'log_text_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-results__log ol' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/*
	|--------------------------------------------------------------------------
	| Render
	|--------------------------------------------------------------------------
	*/

	protected function render(): void {
		$settings = $this->get_settings_for_display();
		$vote_id  = intval( $settings['vote_id'] ?? 0 );

		if ( ! $vote_id && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			$vote_id_from_url = isset( $_GET['wpvp_vote'] ) ? absint( $_GET['wpvp_vote'] ) : 0;
			if ( ! $vote_id_from_url ) {
				echo '<div class="wpvp-results-wrap" style="padding: 40px; text-align: center; background: #f9f9f9; border: 2px dashed #dcdcde; border-radius: 8px;">'
					. '<p style="font-size: 16px; color: #646970; margin: 0;">'
					. esc_html__( 'OWBN Vote Results', 'wp-voting-plugin' )
					. '</p><p style="font-size: 13px; color: #a7aaad; margin: 8px 0 0;">'
					. esc_html__( 'Select a vote in widget settings, or leave on "Dynamic from URL" to show a results list or read from ?wpvp_vote= parameter.', 'wp-voting-plugin' )
					. '</p></div>';
				return;
			}
		}

		$render_settings = array(
			'id'                 => $vote_id,
			'show_title'         => ( $settings['show_title'] ?? 'yes' ) === 'yes',
			'show_winner_banner' => ( $settings['show_winner_banner'] ?? 'yes' ) === 'yes',
			'show_rounds'        => ( $settings['show_rounds'] ?? 'yes' ) === 'yes',
			'show_csv_export'    => ( $settings['show_csv_export'] ?? 'yes' ) === 'yes',
			'show_event_log'     => ( $settings['show_event_log'] ?? 'yes' ) === 'yes',
			'show_voter_list'    => ( $settings['show_voter_list'] ?? 'yes' ) === 'yes',
		);

		echo WPVP_Renderer::render_results( $render_settings );
	}
}
