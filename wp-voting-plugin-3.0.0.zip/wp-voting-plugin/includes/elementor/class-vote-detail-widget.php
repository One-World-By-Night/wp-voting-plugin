<?php
/**
 * Elementor Widget: Vote Detail
 *
 * Displays a single vote with proposal info, ballot form, and
 * optional results section. Extensively styleable via Elementor controls.
 *
 * @package WP_Voting_Plugin
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

class WPVP_Elementor_Vote_Detail_Widget extends \Elementor\Widget_Base {

	public function get_name(): string {
		return 'wpvp_vote_detail';
	}

	public function get_title(): string {
		return __( 'OWBN — Vote Detail', 'wp-voting-plugin' );
	}

	public function get_icon(): string {
		return 'eicon-form-horizontal';
	}

	public function get_categories(): array {
		return array( 'wpvp-voting', 'general' );
	}

	public function get_keywords(): array {
		return array( 'vote', 'voting', 'ballot', 'poll', 'detail', 'wpvp', 'owbn' );
	}

	public function get_style_depends(): array {
		return array( 'wpvp-public' );
	}

	public function get_script_depends(): array {
		return array( 'wpvp-public' );
	}

	/*
	|--------------------------------------------------------------------------
	| Controls
	|--------------------------------------------------------------------------
	*/

	protected function register_controls(): void {
		$this->register_content_controls();
		$this->register_style_header_controls();
		$this->register_style_description_controls();
		$this->register_style_ballot_controls();
		$this->register_style_ranked_controls();
		$this->register_style_notice_controls();
	}

	/**
	 * Content tab.
	 */
	private function register_content_controls(): void {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => __( 'Content', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'vote_id',
			array(
				'label'       => __( 'Vote', 'wp-voting-plugin' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => WPVP_Renderer::get_vote_options(),
				'default'     => '0',
				'label_block' => true,
				'description' => __( 'Select a specific vote or use "Dynamic from URL" to read from ?wpvp_vote= parameter.', 'wp-voting-plugin' ),
			)
		);

		$this->add_control(
			'show_description',
			array(
				'label'        => __( 'Show Description', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_meta',
			array(
				'label'        => __( 'Show Meta (Type, Dates)', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_type_desc',
			array(
				'label'        => __( 'Show Voting Type Description', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_ballot',
			array(
				'label'        => __( 'Show Ballot Form', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_results',
			array(
				'label'        => __( 'Show Results Section', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_vote_history',
			array(
				'label'        => __( 'Show Vote History', 'wp-voting-plugin' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'wp-voting-plugin' ),
				'label_off'    => __( 'No', 'wp-voting-plugin' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Header (title + badge + meta).
	 */
	private function register_style_header_controls(): void {
		$this->start_controls_section(
			'section_style_header',
			array(
				'label' => __( 'Header', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => __( 'Title Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-detail__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => __( 'Title Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-detail__title',
			)
		);

		$this->add_responsive_control(
			'header_gap',
			array(
				'label'      => __( 'Title / Badge Gap', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-vote-detail__header' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'header_margin_bottom',
			array(
				'label'      => __( 'Header Bottom Spacing', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-vote-detail__header' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'heading_meta_style',
			array(
				'label'     => __( 'Meta Row', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'meta_text_color',
			array(
				'label'     => __( 'Meta Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-detail__meta' => 'color: {{VALUE}};',
					'{{WRAPPER}} .wpvp-vote-detail__meta span' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'meta_typography',
				'label'    => __( 'Meta Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-detail__meta',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Description.
	 */
	private function register_style_description_controls(): void {
		$this->start_controls_section(
			'section_style_description',
			array(
				'label' => __( 'Description', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'desc_text_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-detail__description' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'desc_typography',
				'label'    => __( 'Typography', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-vote-detail__description',
			)
		);

		$this->add_responsive_control(
			'desc_margin_bottom',
			array(
				'label'      => __( 'Bottom Spacing', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-vote-detail__description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'type_desc_color',
			array(
				'label'     => __( 'Type Description Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-vote-detail__type-desc' => 'color: {{VALUE}};',
				),
				'separator' => 'before',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Ballot form.
	 */
	private function register_style_ballot_controls(): void {
		$this->start_controls_section(
			'section_style_ballot',
			array(
				'label' => __( 'Ballot Form', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'ballot_bg',
			array(
				'label'     => __( 'Form Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__form' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'ballot_border',
				'label'    => __( 'Form Border', 'wp-voting-plugin' ),
				'selector' => '{{WRAPPER}} .wpvp-ballot__form',
			)
		);

		$this->add_responsive_control(
			'ballot_border_radius',
			array(
				'label'      => __( 'Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-ballot__form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'ballot_padding',
			array(
				'label'      => __( 'Padding', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-ballot__form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		// Radio/checkbox options.
		$this->add_control(
			'heading_option_style',
			array(
				'label'     => __( 'Voting Options', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->start_controls_tabs( 'option_colors' );

		$this->start_controls_tab( 'option_normal', array( 'label' => __( 'Normal', 'wp-voting-plugin' ) ) );
		$this->add_control( 'option_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__option' => 'background-color: {{VALUE}};' ),
		) );
		$this->add_control( 'option_border_color', array(
			'label'     => __( 'Border Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__option' => 'border-color: {{VALUE}};' ),
		) );
		$this->add_control( 'option_text_color', array(
			'label'     => __( 'Text Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__option-text' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_tab();

		$this->start_controls_tab( 'option_hover', array( 'label' => __( 'Hover', 'wp-voting-plugin' ) ) );
		$this->add_control( 'option_hover_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__option:hover' => 'background-color: {{VALUE}};' ),
		) );
		$this->add_control( 'option_hover_border', array(
			'label'     => __( 'Border Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__option:hover' => 'border-color: {{VALUE}};' ),
		) );
		$this->end_controls_tab();

		$this->start_controls_tab( 'option_selected', array( 'label' => __( 'Selected', 'wp-voting-plugin' ) ) );
		$this->add_control( 'option_selected_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .wpvp-ballot__option--selected, {{WRAPPER}} .wpvp-ballot__option:has(input:checked)' => 'background-color: {{VALUE}};',
			),
		) );
		$this->add_control( 'option_selected_border', array(
			'label'     => __( 'Border Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .wpvp-ballot__option--selected, {{WRAPPER}} .wpvp-ballot__option:has(input:checked)' => 'border-color: {{VALUE}};',
			),
		) );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'option_typography',
				'label'     => __( 'Option Typography', 'wp-voting-plugin' ),
				'selector'  => '{{WRAPPER}} .wpvp-ballot__option-text',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'option_desc_color',
			array(
				'label'     => __( 'Option Description Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__option-desc' => 'color: {{VALUE}};',
				),
			)
		);

		// Submit button.
		$this->add_control(
			'heading_submit_style',
			array(
				'label'     => __( 'Submit Button', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->start_controls_tabs( 'submit_colors' );

		$this->start_controls_tab( 'submit_normal', array( 'label' => __( 'Normal', 'wp-voting-plugin' ) ) );
		$this->add_control( 'submit_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__submit-btn' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ),
		) );
		$this->add_control( 'submit_color', array(
			'label'     => __( 'Text Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__submit-btn' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_tab();

		$this->start_controls_tab( 'submit_hover', array( 'label' => __( 'Hover', 'wp-voting-plugin' ) ) );
		$this->add_control( 'submit_hover_bg', array(
			'label'     => __( 'Background', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__submit-btn:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}};' ),
		) );
		$this->add_control( 'submit_hover_color', array(
			'label'     => __( 'Text Color', 'wp-voting-plugin' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .wpvp-ballot__submit-btn:hover' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'submit_typography',
				'label'     => __( 'Submit Typography', 'wp-voting-plugin' ),
				'selector'  => '{{WRAPPER}} .wpvp-ballot__submit-btn',
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'submit_border_radius',
			array(
				'label'      => __( 'Submit Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-ballot__submit-btn' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Ranked/sortable items.
	 */
	private function register_style_ranked_controls(): void {
		$this->start_controls_section(
			'section_style_ranked',
			array(
				'label' => __( 'Ranked Ballot Items', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'ranked_item_bg',
			array(
				'label'     => __( 'Item Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__sortable-item' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'ranked_item_hover_bg',
			array(
				'label'     => __( 'Item Hover Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__sortable-item:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'ranked_item_dragging_bg',
			array(
				'label'     => __( 'Item Dragging Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__sortable-item.dragging' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'ranked_border_color',
			array(
				'label'     => __( 'Item Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__sortable-item' => 'border-bottom-color: {{VALUE}};',
					'{{WRAPPER}} .wpvp-ballot__sortable'      => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'ranked_drop_indicator_color',
			array(
				'label'     => __( 'Drop Indicator Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__sortable-item.drag-over' => 'border-top-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'ranked_text_typography',
				'label'     => __( 'Item Typography', 'wp-voting-plugin' ),
				'selector'  => '{{WRAPPER}} .wpvp-ballot__sortable-text',
				'separator' => 'before',
			)
		);

		// Rank number badge.
		$this->add_control(
			'heading_rank_number',
			array(
				'label'     => __( 'Rank Number', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'rank_number_bg',
			array(
				'label'     => __( 'Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__rank-number' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'rank_number_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__rank-number' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'rank_number_size',
			array(
				'label'      => __( 'Size', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 20, 'max' => 50 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-ballot__rank-number' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		// Drag handle.
		$this->add_control(
			'heading_drag_handle',
			array(
				'label'     => __( 'Drag Handle', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'drag_handle_color',
			array(
				'label'     => __( 'Handle Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__drag-handle' => 'color: {{VALUE}};',
				),
			)
		);

		// Up/down buttons.
		$this->add_control(
			'heading_rank_buttons',
			array(
				'label'     => __( 'Up/Down Buttons', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'rank_btn_color',
			array(
				'label'     => __( 'Button Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__rank-up, {{WRAPPER}} .wpvp-ballot__rank-down' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'rank_btn_border_color',
			array(
				'label'     => __( 'Button Border Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__rank-up, {{WRAPPER}} .wpvp-ballot__rank-down' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'rank_btn_hover_bg',
			array(
				'label'     => __( 'Button Hover Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__rank-up:hover, {{WRAPPER}} .wpvp-ballot__rank-down:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		// Ranked header.
		$this->add_control(
			'heading_ranked_header',
			array(
				'label'     => __( 'Ranking Header Bar', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'ranked_header_bg',
			array(
				'label'     => __( 'Background', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__ranked-header' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'ranked_header_color',
			array(
				'label'     => __( 'Text Color', 'wp-voting-plugin' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .wpvp-ballot__ranked-header' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Style: Notices.
	 */
	private function register_style_notice_controls(): void {
		$this->start_controls_section(
			'section_style_notices',
			array(
				'label' => __( 'Notices', 'wp-voting-plugin' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$notice_types = array(
			'info'    => __( 'Info', 'wp-voting-plugin' ),
			'success' => __( 'Success', 'wp-voting-plugin' ),
			'warning' => __( 'Warning', 'wp-voting-plugin' ),
			'error'   => __( 'Error', 'wp-voting-plugin' ),
		);

		foreach ( $notice_types as $slug => $label ) {
			$this->add_control(
				'notice_heading_' . $slug,
				array(
					'label'     => $label,
					'type'      => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				)
			);

			$this->add_control(
				'notice_bg_' . $slug,
				array(
					'label'     => __( 'Background', 'wp-voting-plugin' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .wpvp-notice--' . $slug => 'background-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'notice_border_' . $slug,
				array(
					'label'     => __( 'Left Border Color', 'wp-voting-plugin' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .wpvp-notice--' . $slug => 'border-left-color: {{VALUE}};',
					),
				)
			);

			$this->add_control(
				'notice_color_' . $slug,
				array(
					'label'     => __( 'Text Color', 'wp-voting-plugin' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => array(
						'{{WRAPPER}} .wpvp-notice--' . $slug => 'color: {{VALUE}};',
					),
				)
			);
		}

		$this->add_responsive_control(
			'notice_border_radius',
			array(
				'label'      => __( 'Border Radius', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-notice' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
				'separator'  => 'before',
			)
		);

		$this->add_responsive_control(
			'notice_padding',
			array(
				'label'      => __( 'Padding', 'wp-voting-plugin' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .wpvp-notice' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/*
	|--------------------------------------------------------------------------
	| Render
	|--------------------------------------------------------------------------
	*/

	protected function render(): void {
		$settings = $this->get_settings_for_display();
		$vote_id  = intval( $settings['vote_id'] ?? 0 );

		// In the editor, show a helpful placeholder if no vote selected.
		if ( ! $vote_id && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			$vote_id_from_url = isset( $_GET['wpvp_vote'] ) ? absint( $_GET['wpvp_vote'] ) : 0;
			if ( ! $vote_id_from_url ) {
				echo '<div class="wpvp-vote-detail" style="padding: 40px; text-align: center; background: #f9f9f9; border: 2px dashed #dcdcde; border-radius: 8px;">'
					. '<p style="font-size: 16px; color: #646970; margin: 0;">'
					. esc_html__( 'OWBN Vote Detail', 'wp-voting-plugin' )
					. '</p><p style="font-size: 13px; color: #a7aaad; margin: 8px 0 0;">'
					. esc_html__( 'Select a vote in the widget settings, or set to "Dynamic from URL" to use ?wpvp_vote= parameter.', 'wp-voting-plugin' )
					. '</p></div>';
				return;
			}
		}

		$render_settings = array(
			'id'                => $vote_id,
			'show_description'  => $settings['show_description'] ?? 'yes',
			'show_meta'         => $settings['show_meta'] ?? 'yes',
			'show_type_desc'    => $settings['show_type_desc'] ?? 'yes',
			'show_ballot'       => $settings['show_ballot'] ?? 'yes',
			'show_results'      => $settings['show_results'] ?? 'yes',
			'show_vote_history' => $settings['show_vote_history'] ?? 'yes',
		);

		echo WPVP_Renderer::render_vote_detail( $render_settings );
	}
}
