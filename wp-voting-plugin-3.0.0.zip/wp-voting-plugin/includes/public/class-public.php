<?php
/**
 * Frontend bootstrap: shortcodes, Elementor widgets, asset enqueue.
 */

defined( 'ABSPATH' ) || exit;

class WPVP_Public {

	/** @var bool Track whether assets need enqueuing. */
	private $enqueue = false;

	public function __construct() {
		add_shortcode( 'wpvp_votes', array( $this, 'shortcode_votes' ) );
		add_shortcode( 'wpvp_vote', array( $this, 'shortcode_vote' ) );
		add_shortcode( 'wpvp_results', array( $this, 'shortcode_results' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_footer', array( $this, 'maybe_enqueue_assets' ) );
	}

	/*
	------------------------------------------------------------------
	 *  Asset registration.
	 * ----------------------------------------------------------------*/

	/**
	 * Register (but don't enqueue yet) CSS and JS.
	 * Assets are only enqueued when a shortcode is present.
	 */
	public function register_assets(): void {
		wp_register_style(
			'wpvp-public',
			WPVP_PLUGIN_URL . 'assets/css/public.css',
			array(),
			WPVP_VERSION
		);

		wp_register_script(
			'wpvp-public',
			WPVP_PLUGIN_URL . 'assets/js/public.js',
			array( 'jquery' ),
			WPVP_VERSION,
			true
		);

		wp_localize_script(
			'wpvp-public',
			'wpvp_public',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'wpvp_public' ),
				'i18n'     => array(
					'submitting'     => __( 'Submitting...', 'wp-voting-plugin' ),
					'success'        => __( 'Your vote has been recorded.', 'wp-voting-plugin' ),
					'error'          => __( 'An error occurred. Please try again.', 'wp-voting-plugin' ),
					'confirm_submit' => __( 'Submit your vote? This cannot be changed.', 'wp-voting-plugin' ),
					'confirm_revote' => __( 'Update your vote?', 'wp-voting-plugin' ),
					'rank_required'  => __( 'Please rank at least one option.', 'wp-voting-plugin' ),
					'select_option'  => __( 'Please select an option.', 'wp-voting-plugin' ),
					'login_required'    => __( 'You must be logged in to vote.', 'wp-voting-plugin' ),
					'change_vote'       => __( 'Change Vote', 'wp-voting-plugin' ),
					'revote_notice'     => __( 'You can change your vote at any time before voting closes.', 'wp-voting-plugin' ),
					/* translators: %1$s: option name, %2$d: rank number */
					'rank_aria'         => __( '%1$s — Rank %2$d', 'wp-voting-plugin' ),
					'close'             => __( 'Close', 'wp-voting-plugin' ),
					'loading'           => __( 'Loading...', 'wp-voting-plugin' ),
					'content_not_loaded' => __( 'Content could not be loaded.', 'wp-voting-plugin' ),
					'error_loading'     => __( 'Error loading content. Please try again.', 'wp-voting-plugin' ),
					'comment_placeholder' => __( 'Add an optional comment or rationale for your vote...', 'wp-voting-plugin' ),
				),
			)
		);
	}

	/**
	 * Enqueue assets in footer if a shortcode was rendered.
	 */
	public function maybe_enqueue_assets(): void {
		if ( $this->enqueue ) {
			wp_enqueue_style( 'wpvp-public' );
			wp_enqueue_script( 'wpvp-public' );
		}
	}

	/**
	 * Mark that frontend assets should be enqueued.
	 */
	private function flag_enqueue(): void {
		$this->enqueue = true;
		// If called late (after wp_enqueue_scripts), enqueue directly.
		if ( did_action( 'wp_enqueue_scripts' ) ) {
			wp_enqueue_style( 'wpvp-public' );
			wp_enqueue_script( 'wpvp-public' );
		}
	}

	/*
	------------------------------------------------------------------
	 *  Shortcodes.
	 * ----------------------------------------------------------------*/

	/**
	 * [wpvp_votes] — List of votes.
	 *
	 * Attributes:
	 *  - status: open|closed|completed|all (default: open)
	 *  - limit:  number of votes to show (default: 20)
	 */
	public function shortcode_votes( $atts ): string {
		$this->flag_enqueue();

		$atts = shortcode_atts(
			array(
				'status' => 'open',
				'limit'  => 20,
			),
			$atts,
			'wpvp_votes'
		);

		return WPVP_Renderer::render_vote_list( $atts );
	}

	/**
	 * [wpvp_vote id="123"] — Single vote detail + ballot form.
	 */
	public function shortcode_vote( $atts ): string {
		$this->flag_enqueue();

		$vote_id_from_url = isset( $_GET['wpvp_vote'] ) ? absint( $_GET['wpvp_vote'] ) : 0;

		$atts = shortcode_atts(
			array(
				'id' => $vote_id_from_url,
			),
			$atts,
			'wpvp_vote'
		);

		return WPVP_Renderer::render_vote_detail( $atts );
	}

	/**
	 * [wpvp_results id="123"] — Results display.
	 * If no ID provided, shows a list of votes with available results.
	 */
	public function shortcode_results( $atts ): string {
		$this->flag_enqueue();

		$vote_id_from_url = isset( $_GET['wpvp_vote'] ) ? absint( $_GET['wpvp_vote'] ) : 0;

		$atts = shortcode_atts(
			array(
				'id' => $vote_id_from_url,
			),
			$atts,
			'wpvp_results'
		);

		return WPVP_Renderer::render_results( $atts );
	}
}
