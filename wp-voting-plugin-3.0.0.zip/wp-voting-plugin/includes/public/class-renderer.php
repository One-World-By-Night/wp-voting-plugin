<?php
/**
 * Shared rendering logic for shortcodes and Elementor widgets.
 *
 * Centralizes data fetching and template inclusion so both
 * code paths produce identical output. Elementor widgets pass
 * additional display settings via the $display array.
 *
 * @package WP_Voting_Plugin
 */

defined( 'ABSPATH' ) || exit;

class WPVP_Renderer {

	/**
	 * Render a list of votes.
	 *
	 * @param array $settings Merged shortcode atts / Elementor controls.
	 * @return string HTML output.
	 */
	public static function render_vote_list( array $settings = array() ): string {
		$defaults = array(
			'status'             => 'open',
			'limit'              => 20,
			'is_results_context' => false,
		);

		$settings = wp_parse_args( $settings, $defaults );

		if ( $settings['is_results_context'] ) {
			return self::render_results_list( $settings );
		}

		$limit = max( 1, intval( $settings['limit'] ) );

		$args = array(
			'per_page' => $limit * 3,
			'page'     => 1,
		);

		if ( 'all' !== $settings['status'] ) {
			if ( strpos( $settings['status'], ',' ) !== false ) {
				$statuses       = array_map( 'sanitize_key', explode( ',', $settings['status'] ) );
				$args['status'] = array_filter( $statuses );
			} else {
				$args['status'] = sanitize_key( $settings['status'] );
			}
		}

		$all_votes = WPVP_Database::get_votes( $args );
		$user_id   = get_current_user_id();

		$votes = array();
		foreach ( $all_votes as $vote ) {
			if ( WPVP_Permissions::can_view_vote( $user_id, $vote ) ) {
				$votes[] = $vote;
			}
			if ( count( $votes ) >= $limit ) {
				break;
			}
		}

		$atts    = $settings;
		$display = $settings;

		ob_start();
		include WPVP_PLUGIN_DIR . 'templates/public/vote-list.php';
		return ob_get_clean();
	}

	/**
	 * Render list of votes that have available results.
	 *
	 * @param array $settings Display settings.
	 * @return string HTML output.
	 */
	private static function render_results_list( array $settings ): string {
		$user_id = get_current_user_id();
		$limit   = max( 1, intval( $settings['limit'] ?? 100 ) );

		$args = array(
			'per_page' => 100,
			'page'     => 1,
		);

		$all_votes          = WPVP_Database::get_votes( $args );
		$votes_with_results = array();

		foreach ( $all_votes as $vote ) {
			$is_completed_or_closed = in_array( $vote->voting_stage, array( 'completed', 'closed' ), true );

			$show_open_results = false;
			if ( 'open' === $vote->voting_stage ) {
				$vote_settings     = json_decode( $vote->settings, true );
				$vote_settings     = $vote_settings ? $vote_settings : array();
				$show_open_results = ! empty( $vote_settings['show_results_before_closing'] );
			}

			if ( ! $is_completed_or_closed && ! $show_open_results ) {
				continue;
			}

			if ( ! WPVP_Permissions::can_view_vote( $user_id, $vote ) ) {
				continue;
			}

			if ( ! $show_open_results ) {
				$results = WPVP_Database::get_results( $vote->id );
				if ( ! $results ) {
					continue;
				}
			}

			if ( ! WPVP_Permissions::can_view_results( $user_id, $vote->id ) ) {
				continue;
			}

			$votes_with_results[] = $vote;

			if ( count( $votes_with_results ) >= $limit ) {
				break;
			}
		}

		$votes              = $votes_with_results;
		$is_results_context = true;
		$atts               = $settings;
		$display            = $settings;

		ob_start();
		include WPVP_PLUGIN_DIR . 'templates/public/vote-list.php';
		return ob_get_clean();
	}

	/**
	 * Render single vote detail with ballot form.
	 *
	 * @param array $settings Merged shortcode atts / Elementor controls.
	 * @return string HTML output.
	 */
	public static function render_vote_detail( array $settings = array() ): string {
		$defaults = array(
			'id' => 0,
		);

		$settings = wp_parse_args( $settings, $defaults );

		$vote_id = absint( $settings['id'] );
		if ( ! $vote_id ) {
			$vote_id = isset( $_GET['wpvp_vote'] ) ? absint( $_GET['wpvp_vote'] ) : 0;
		}

		if ( ! $vote_id ) {
			return '<div class="wpvp-vote-detail"><p class="wpvp-error">'
				. esc_html__( 'Invalid vote ID.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$vote = WPVP_Database::get_vote( $vote_id );
		if ( ! $vote ) {
			return '<div class="wpvp-vote-detail"><p class="wpvp-error">'
				. esc_html__( 'Vote not found.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$user_id = get_current_user_id();
		$display = $settings;

		ob_start();
		include WPVP_PLUGIN_DIR . 'templates/public/vote-detail.php';
		return ob_get_clean();
	}

	/**
	 * Render results for a vote.
	 *
	 * @param array $settings Merged shortcode atts / Elementor controls.
	 * @return string HTML output.
	 */
	public static function render_results( array $settings = array() ): string {
		$defaults = array(
			'id' => 0,
		);

		$settings = wp_parse_args( $settings, $defaults );

		$vote_id = absint( $settings['id'] );
		if ( ! $vote_id ) {
			$vote_id = isset( $_GET['wpvp_vote'] ) ? absint( $_GET['wpvp_vote'] ) : 0;
		}

		if ( ! $vote_id ) {
			return self::render_results_list(
				array_merge( $settings, array( 'is_results_context' => true, 'limit' => 100 ) )
			);
		}

		$user_id = get_current_user_id();
		if ( ! WPVP_Permissions::can_view_results( $user_id, $vote_id ) ) {
			return '<div class="wpvp-results-wrap"><p class="wpvp-error">'
				. esc_html__( 'You do not have permission to view these results.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$vote = WPVP_Database::get_vote( $vote_id );
		if ( ! $vote ) {
			return '<div class="wpvp-results-wrap"><p class="wpvp-error">'
				. esc_html__( 'Vote not found.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$results = WPVP_Database::get_results( $vote_id );

		// Live results calculation for open votes.
		if ( ! $results && 'open' === $vote->voting_stage ) {
			$decoded_settings = json_decode( $vote->settings, true );
			$vote_settings    = $decoded_settings ? $decoded_settings : array();
			$show_live        = ! empty( $vote_settings['show_results_before_closing'] );

			if ( $show_live ) {
				$results = self::calculate_live_results( $vote, $vote_id );
			}
		}

		if ( ! $results ) {
			return '<div class="wpvp-results-wrap"><p class="wpvp-error">'
				. esc_html__( 'Results are not yet available.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$display = $settings;

		try {
			ob_start();
			include WPVP_PLUGIN_DIR . 'templates/public/results.php';
			return ob_get_clean();
		} catch ( Exception $e ) {
			error_log( 'WPVP results template error: ' . $e->getMessage() );
			return '<div class="wpvp-results-wrap"><p class="wpvp-error">'
				. esc_html__( 'An error occurred while displaying results.', 'wp-voting-plugin' ) . '</p></div>';
		}
	}

	/**
	 * Calculate live results on-the-fly without saving to database.
	 *
	 * @param object $vote    Vote record.
	 * @param int    $vote_id Vote ID.
	 * @return object|null Results object or null on failure.
	 */
	private static function calculate_live_results( object $vote, int $vote_id ): ?object {
		try {
			$algo = WPVP_Processor::get_algorithm( $vote->voting_type );
			if ( ! $algo ) {
				return null;
			}

			$ballots = WPVP_Database::get_ballots( $vote_id );
			if ( empty( $ballots ) ) {
				return null;
			}

			$raw_options = json_decode( $vote->voting_options, true );
			if ( ! is_array( $raw_options ) || empty( $raw_options ) ) {
				return null;
			}

			$options    = array_column( $raw_options, 'text' );
			$config     = array( 'num_seats' => max( 1, intval( $vote->number_of_winners ) ) );
			$calculated = $algo->process( $ballots, $options, $config );

			if ( ! $calculated || ! is_array( $calculated ) ) {
				return null;
			}

			return (object) array(
				'vote_id'       => $vote_id,
				'total_votes'   => count( $ballots ),
				'total_voters'  => count( $ballots ),
				'final_results' => isset( $calculated['final'] ) && is_array( $calculated['final'] )
					? $calculated['final'] : array(),
				'winner_data'   => isset( $calculated['winner'] ) && is_array( $calculated['winner'] )
					? $calculated['winner'] : array(),
				'rounds_data'   => isset( $calculated['rounds'] ) && is_array( $calculated['rounds'] )
					? $calculated['rounds'] : array(),
				'statistics'    => isset( $calculated['stats'] ) && is_array( $calculated['stats'] )
					? $calculated['stats'] : array(),
				'calculated_at' => current_time( 'mysql' ),
				'is_live'       => true,
			);
		} catch ( Exception $e ) {
			error_log( 'WPVP live results calculation error: ' . $e->getMessage() );
			return null;
		}
	}

	/**
	 * Get vote options for Elementor widget dropdowns.
	 *
	 * @return array Associative array of vote_id => label.
	 */
	public static function get_vote_options(): array {
		$options = array( '0' => __( '-- Dynamic from URL --', 'wp-voting-plugin' ) );

		$votes = WPVP_Database::get_votes( array( 'per_page' => 200, 'page' => 1 ) );
		$stages = WPVP_Database::get_vote_stages();

		foreach ( $votes as $vote ) {
			$stage_label = $stages[ $vote->voting_stage ] ?? $vote->voting_stage;
			$options[ (string) $vote->id ] = sprintf(
				'#%d %s [%s]',
				$vote->id,
				$vote->proposal_name,
				$stage_label
			);
		}

		return $options;
	}
}
