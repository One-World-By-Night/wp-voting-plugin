<?php
/**
 * Frontend bootstrap: shortcodes, Elementor widgets, asset enqueue.
 */

defined( 'ABSPATH' ) || exit;

class WPVP_Public {

	/** @var bool Track whether assets need enqueuing. */
	private $enqueue = false;

	public function __construct() {
		add_shortcode( 'wpvp_votes', array( $this, 'shortcode_votes' ) );
		add_shortcode( 'wpvp_vote', array( $this, 'shortcode_vote' ) );
		add_shortcode( 'wpvp_results', array( $this, 'shortcode_results' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_footer', array( $this, 'maybe_enqueue_assets' ) );

		// Elementor widget registration.
		add_action( 'elementor/widgets/register', array( $this, 'register_elementor_widgets' ) );
	}


	/**
	 * Register (but don't enqueue yet) CSS and JS.
	 * Assets are only enqueued when a shortcode is present.
	 */
	public function register_assets(): void {
		wp_register_style(
			'wpvp-public',
			WPVP_PLUGIN_URL . 'assets/css/public.css',
			array(),
			WPVP_VERSION
		);

		wp_register_script(
			'wpvp-public',
			WPVP_PLUGIN_URL . 'assets/js/public.js',
			array( 'jquery' ),
			WPVP_VERSION,
			true
		);

		wp_localize_script(
			'wpvp-public',
			'wpvp_public',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'wpvp_public' ),
				'i18n'     => array(
					'submitting'     => __( 'Submitting...', 'wp-voting-plugin' ),
					'success'        => __( 'Your vote has been recorded.', 'wp-voting-plugin' ),
					'error'          => __( 'An error occurred. Please try again.', 'wp-voting-plugin' ),
					'confirm_submit' => __( 'Submit your vote? This cannot be changed.', 'wp-voting-plugin' ),
					'confirm_revote' => __( 'Update your vote?', 'wp-voting-plugin' ),
					'rank_required'  => __( 'Please rank at least one option.', 'wp-voting-plugin' ),
					'select_option'  => __( 'Please select an option.', 'wp-voting-plugin' ),
					'login_required'    => __( 'You must be logged in to vote.', 'wp-voting-plugin' ),
					'change_vote'       => __( 'Change Vote', 'wp-voting-plugin' ),
					'revote_notice'     => __( 'You can change your vote at any time before voting closes.', 'wp-voting-plugin' ),
					/* translators: %1$s: option name, %2$d: rank number */
					'rank_aria'         => __( '%1$s — Rank %2$d', 'wp-voting-plugin' ),
					'close'             => __( 'Close', 'wp-voting-plugin' ),
					'all'               => __( 'All', 'wp-voting-plugin' ),
					'loading'           => __( 'Loading...', 'wp-voting-plugin' ),
					'content_not_loaded' => __( 'Content could not be loaded.', 'wp-voting-plugin' ),
					'error_loading'     => __( 'Error loading content. Please try again.', 'wp-voting-plugin' ),
					'comment_placeholder' => __( 'Add an optional comment or rationale for your vote...', 'wp-voting-plugin' ),
				),
			)
		);
	}

	/**
	 * Enqueue assets in footer if a shortcode was rendered.
	 */
	public function maybe_enqueue_assets(): void {
		if ( $this->enqueue ) {
			wp_enqueue_style( 'wpvp-public' );
			wp_enqueue_script( 'wpvp-public' );
		}
	}

	/**
	 * Mark that frontend assets should be enqueued.
	 */
	private function flag_enqueue(): void {
		$this->enqueue = true;
		// If called late (after wp_enqueue_scripts), enqueue directly.
		if ( did_action( 'wp_enqueue_scripts' ) ) {
			wp_enqueue_style( 'wpvp-public' );
			wp_enqueue_script( 'wpvp-public' );
		}
	}


	/**
	 * [wpvp_votes] — List of votes.
	 *
	 * Attributes:
	 *  - status:   open|closed|completed|all (default: scheduled,open)
	 *  - limit:    number of votes per page (default: 10)
	 *  - sort_col: title|type|votes|start_date|end_date|status (default: start_date)
	 *  - sort_dir: asc|desc (default: asc)
	 */
	public function shortcode_votes( $atts ): string {
		$this->flag_enqueue();

		$atts = shortcode_atts(
			array(
				'status'   => 'scheduled,open',
				'limit'    => 10,
				'sort_col' => 'start_date',
				'sort_dir' => 'asc',
			),
			$atts,
			'wpvp_votes'
		);

		$args = array(
			'per_page' => 10000,
			'page'     => 1,
		);

		if ( 'all' !== $atts['status'] ) {
			if ( strpos( $atts['status'], ',' ) !== false ) {
				$statuses = array_filter( array_map( 'sanitize_key', explode( ',', $atts['status'] ) ) );
				if ( in_array( 'closed', $statuses, true ) && ! in_array( 'withdrawn', $statuses, true ) ) {
					$statuses[] = 'withdrawn';
				}
				$args['status'] = $statuses;
			} else {
				$args['status'] = sanitize_key( $atts['status'] );
			}
		}

		$all_votes = WPVP_Database::get_votes( $args );
		$user_id   = get_current_user_id();

		// Filter to only votes the current user can view.
		$votes = array();
		foreach ( $all_votes as $vote ) {
			if ( WPVP_Permissions::can_view_vote( $user_id, $vote ) ) {
				$votes[] = $vote;
			}
		}

		// Pre-compute data needed for sorting and filtering.
		$vote_ids    = wp_list_pluck( $votes, 'id' );
		$ballot_counts = ! empty( $vote_ids ) ? WPVP_Database::get_ballot_counts( $vote_ids ) : array();
		$results_cache = array();

		foreach ( $votes as $vote ) {
			$vote->_ballot_count = isset( $ballot_counts[ $vote->id ] ) ? (int) $ballot_counts[ $vote->id ] : 0;
			$vote->_result_text  = '';
			$vote->_outcome      = '';

			if ( in_array( $vote->voting_stage, array( 'closed', 'completed', 'withdrawn' ), true ) ) {
				$vote_results = WPVP_Database::get_results( (int) $vote->id );
				if ( $vote_results ) {
					$wd = $vote_results->winner_data ? $vote_results->winner_data : array();
					$fr = $vote_results->final_results ? $vote_results->final_results : array();
					if ( ! empty( $wd['tie'] ) ) {
						$vote->_outcome     = 'tied';
						$vote->_result_text = __( 'Tied', 'wp-voting-plugin' );
					} elseif ( isset( $fr['passed'] ) ) {
						$vote->_outcome     = $fr['passed'] ? 'passed' : 'failed';
						$vote->_result_text = $fr['passed'] ? __( 'Passed', 'wp-voting-plugin' ) : __( 'Objected', 'wp-voting-plugin' );
					} elseif ( ! empty( $wd['winners'] ) ) {
						$vote->_outcome     = 'winner';
						$vote->_result_text = implode( ', ', $wd['winners'] );
					} elseif ( ! empty( $wd['winner'] ) ) {
						$vote->_outcome     = 'winner';
						$vote->_result_text = $wd['winner'];
					}
				}
			}

			$type_list             = json_decode( $vote->classification, true );
			$vote->_type_display   = is_array( $type_list ) && ! empty( $type_list ) ? implode( ', ', $type_list ) : '';
		}

		// Read URL parameters for server-side sort, filter, pagination.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$sort_col = isset( $_GET['wpvp_sort'] ) ? sanitize_key( $_GET['wpvp_sort'] ) : $atts['sort_col'];
		$sort_dir = isset( $_GET['wpvp_dir'] ) ? sanitize_key( $_GET['wpvp_dir'] ) : $atts['sort_dir'];
		$sort_dir = in_array( $sort_dir, array( 'asc', 'desc' ), true ) ? $sort_dir : 'asc';

		$current_page = isset( $_GET['wpvp_page'] ) ? max( 1, intval( $_GET['wpvp_page'] ) ) : 1;
		$per_page     = isset( $_GET['wpvp_pp'] ) ? max( 1, intval( $_GET['wpvp_pp'] ) ) : max( 1, intval( $atts['limit'] ) );

		$search_query    = isset( $_GET['wpvp_s'] ) ? sanitize_text_field( $_GET['wpvp_s'] ) : '';
		$filter_proposer = isset( $_GET['wpvp_proposer'] ) ? sanitize_text_field( $_GET['wpvp_proposer'] ) : '';

		// Type and outcome support multi-select (arrays from checkboxes).
		$filter_type = array();
		if ( isset( $_GET['wpvp_type'] ) ) {
			$raw = is_array( $_GET['wpvp_type'] ) ? $_GET['wpvp_type'] : array( $_GET['wpvp_type'] );
			$filter_type = array_filter( array_map( 'sanitize_text_field', $raw ) );
		}

		$filter_outcome = array();
		if ( isset( $_GET['wpvp_outcome'] ) ) {
			$raw = is_array( $_GET['wpvp_outcome'] ) ? $_GET['wpvp_outcome'] : array( $_GET['wpvp_outcome'] );
			$filter_outcome = array_filter( array_map( 'sanitize_key', $raw ) );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		// Build unique sorted lists for filter dropdowns (before filtering).
		$proposers = array();
		$type_list_all = array();
		foreach ( $votes as $v ) {
			if ( ! empty( $v->proposed_by ) && ! in_array( $v->proposed_by, $proposers, true ) ) {
				$proposers[] = $v->proposed_by;
			}
			if ( ! empty( $v->_type_display ) && ! in_array( $v->_type_display, $type_list_all, true ) ) {
				$type_list_all[] = $v->_type_display;
			}
		}
		sort( $proposers );
		sort( $type_list_all );

		// Apply search + filters.
		if ( $search_query || $filter_proposer || ! empty( $filter_type ) || ! empty( $filter_outcome ) ) {
			$votes = array_filter( $votes, function ( $v ) use ( $search_query, $filter_proposer, $filter_type, $filter_outcome ) {
				if ( $search_query && stripos( $v->proposal_name, $search_query ) === false ) {
					return false;
				}
				if ( $filter_proposer && strcasecmp( $v->proposed_by ?? '', $filter_proposer ) !== 0 ) {
					return false;
				}
				if ( ! empty( $filter_type ) ) {
					$match = false;
					foreach ( $filter_type as $ft ) {
						if ( strcasecmp( $v->_type_display, $ft ) === 0 ) {
							$match = true;
							break;
						}
					}
					if ( ! $match ) return false;
				}
				if ( ! empty( $filter_outcome ) && ! in_array( $v->_outcome, $filter_outcome, true ) ) {
					return false;
				}
				return true;
			} );
			$votes = array_values( $votes );
		}

		// Sort.
		$sort_field_map = array(
			'title'       => 'proposal_name',
			'proposed_by' => 'proposed_by',
			'type'        => '_type_display',
			'start_date'  => 'opening_date',
			'end_date'    => 'closing_date',
			'votes'       => '_ballot_count',
			'status'      => 'voting_stage',
			'result'      => '_result_text',
		);
		$sort_field = isset( $sort_field_map[ $sort_col ] ) ? $sort_field_map[ $sort_col ] : 'opening_date';
		$sort_asc   = ( 'asc' === $sort_dir );

		usort( $votes, function ( $a, $b ) use ( $sort_field, $sort_asc ) {
			$va = $a->{$sort_field} ?? '';
			$vb = $b->{$sort_field} ?? '';

			if ( is_numeric( $va ) && is_numeric( $vb ) ) {
				$cmp = (float) $va - (float) $vb;
			} else {
				$cmp = strnatcasecmp( (string) $va, (string) $vb );
			}

			return $sort_asc ? $cmp : -$cmp;
		} );

		// Paginate.
		$total_votes = count( $votes );
		$total_pages = max( 1, (int) ceil( $total_votes / $per_page ) );
		$current_page = min( $current_page, $total_pages );
		$offset       = ( $current_page - 1 ) * $per_page;
		$paged_votes  = array_slice( $votes, $offset, $per_page );

		// Pass data to template.
		$pagination = array(
			'current_page' => $current_page,
			'total_pages'  => $total_pages,
			'total_votes'  => $total_votes,
			'per_page'     => $per_page,
			'sort_col'     => $sort_col,
			'sort_dir'     => $sort_dir,
			'search'       => $search_query,
			'proposer'     => $filter_proposer,
			'type'         => $filter_type,
			'outcome'      => $filter_outcome,
			'proposers'    => $proposers,
			'types'        => $type_list_all,
		);

		$votes = $paged_votes;

		ob_start();
		include WPVP_PLUGIN_DIR . 'templates/public/vote-list.php';
		return ob_get_clean();
	}

	/**
	 * [wpvp_vote id="123"] — Single vote detail + ballot form.
	 */
	public function shortcode_vote( $atts ): string {
		$this->flag_enqueue();

		// Check URL parameter first, then shortcode attribute.
		$vote_id_from_url = isset( $_GET['wpvp_vote'] ) ? absint( $_GET['wpvp_vote'] ) : 0;

		$atts = shortcode_atts(
			array(
				'id' => $vote_id_from_url,
			),
			$atts,
			'wpvp_vote'
		);

		$vote_id = absint( $atts['id'] );
		if ( ! $vote_id ) {
			return '<div class="wpvp-vote-detail"><p class="wpvp-error">' . esc_html__( 'Invalid vote ID.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$vote = WPVP_Database::get_vote( $vote_id );
		if ( ! $vote ) {
			return '<div class="wpvp-vote-detail"><p class="wpvp-error">' . esc_html__( 'Vote not found.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$user_id = get_current_user_id();

		ob_start();
		include WPVP_PLUGIN_DIR . 'templates/public/vote-detail.php';
		return ob_get_clean();
	}

	/**
	 * [wpvp_results id="123"] — Results display.
	 * If no ID provided, shows a list of votes with available results.
	 */
	public function shortcode_results( $atts ): string {
		$this->flag_enqueue();

		// Check URL parameter first, then shortcode attribute.
		$vote_id_from_url = isset( $_GET['wpvp_vote'] ) ? absint( $_GET['wpvp_vote'] ) : 0;

		$atts = shortcode_atts(
			array(
				'id' => $vote_id_from_url,
			),
			$atts,
			'wpvp_results'
		);

		$vote_id = absint( $atts['id'] );

		// If no vote ID, show list of votes with available results.
		if ( ! $vote_id ) {
			return $this->render_results_list();
		}

		$user_id = get_current_user_id();
		if ( ! WPVP_Permissions::can_view_results( $user_id, $vote_id ) ) {
			return '<div class="wpvp-results-wrap"><p class="wpvp-error">' . esc_html__( 'You do not have permission to view these results.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$vote = WPVP_Database::get_vote( $vote_id );
		if ( ! $vote ) {
			return '<div class="wpvp-results-wrap"><p class="wpvp-error">' . esc_html__( 'Vote not found.', 'wp-voting-plugin' ) . '</p></div>';
		}

		$results = WPVP_Database::get_results( $vote_id );

		// If no saved results, check if we should calculate live results for open votes.
		if ( ! $results && 'open' === $vote->voting_stage ) {
			$decoded_settings = json_decode( $vote->settings, true );
			$settings         = $decoded_settings ? $decoded_settings : array();
			$show_live        = ! empty( $settings['show_results_before_closing'] );

			if ( $show_live ) {
				try {
					// Calculate results on-the-fly WITHOUT saving (to avoid modifying the vote).
					$algo = WPVP_Processor::get_algorithm( $vote->voting_type );

					if ( ! $algo ) {
						error_log( sprintf( 'WPVP live results: No algorithm found for voting type "%s" (vote ID: %d)', $vote->voting_type, $vote_id ) );
					}

					if ( $algo ) {
						$ballots = WPVP_Database::get_ballots( $vote_id );

						// Only calculate if there are ballots.
						if ( ! empty( $ballots ) ) {
							$raw_options = json_decode( $vote->voting_options, true );
							if ( is_array( $raw_options ) && ! empty( $raw_options ) ) {
								$options = array_column( $raw_options, 'text' );

								$config = array(
									'num_seats' => max( 1, intval( $vote->number_of_winners ) ),
								);

								// Run the algorithm (calculation only, no saving).
								$calculated = $algo->process( $ballots, $options, $config );

								// Create temporary results object with validated data.
								if ( ! $calculated || ! is_array( $calculated ) ) {
									error_log( sprintf( 'WPVP live results: Algorithm returned invalid data for vote ID %d', $vote_id ) );
								}

								if ( $calculated && is_array( $calculated ) ) {
									// Ensure all expected keys exist and are arrays.
									$final_results = isset( $calculated['final'] ) && is_array( $calculated['final'] )
										? $calculated['final']
										: array();
									$winner_data   = isset( $calculated['winner'] ) && is_array( $calculated['winner'] )
										? $calculated['winner']
										: array();
									$rounds_data   = isset( $calculated['rounds'] ) && is_array( $calculated['rounds'] )
										? $calculated['rounds']
										: array();
									$statistics    = isset( $calculated['stats'] ) && is_array( $calculated['stats'] )
										? $calculated['stats']
										: array();

									$results = (object) array(
										'vote_id'       => $vote_id,
										'total_votes'   => count( $ballots ),
										'total_voters'  => count( $ballots ),
										'final_results' => $final_results,
										'winner_data'   => $winner_data,
										'rounds_data'   => $rounds_data,
										'statistics'    => $statistics,
										'calculated_at' => current_time( 'mysql' ),
										'is_live'       => true,
									);
								}
							}
						}
					}
				} catch ( Exception $e ) {
					// Log the error but don't crash the page.
					error_log( 'WPVP live results calculation error: ' . $e->getMessage() );
				}
			}
		}

		if ( ! $results ) {
			return '<div class="wpvp-results-wrap"><p class="wpvp-error">' . esc_html__( 'Results are not yet available.', 'wp-voting-plugin' ) . '</p></div>';
		}

		// Wrap template rendering in try-catch to prevent uncaught errors.
		try {
			ob_start();
			include WPVP_PLUGIN_DIR . 'templates/public/results.php';
			return ob_get_clean();
		} catch ( Exception $e ) {
			error_log( 'WPVP results template error: ' . $e->getMessage() );
			return '<div class="wpvp-results-wrap"><p class="wpvp-error">' . esc_html__( 'An error occurred while displaying results.', 'wp-voting-plugin' ) . '</p></div>';
		}
	}

	/**
	 * Render a list of votes with available results.
	 */
	private function render_results_list(): string {
		$user_id = get_current_user_id();

		// Fetch completed and closed votes.
		$args = array(
			'per_page' => 10000,
			'page'     => 1,
		);

		$all_votes = WPVP_Database::get_votes( $args );

		// Filter to votes with results that user can view.
		$votes_with_results = array();
		foreach ( $all_votes as $vote ) {
			// Include completed, closed, withdrawn, or open votes with "show results before closing" enabled.
			$is_completed_or_closed = in_array( $vote->voting_stage, array( 'completed', 'closed', 'withdrawn' ), true );

			$show_open_results = false;
			if ( 'open' === $vote->voting_stage ) {
				$settings = json_decode( $vote->settings, true );
				$settings = $settings ? $settings : array();
				$show_open_results = ! empty( $settings['show_results_before_closing'] );
			}

			if ( ! $is_completed_or_closed && ! $show_open_results ) {
				continue;
			}

			// Check if user can view this vote.
			if ( ! WPVP_Permissions::can_view_vote( $user_id, $vote ) ) {
				continue;
			}

			// Check if results exist (not required for open votes with "show results before closing").
			if ( ! $show_open_results ) {
				$results = WPVP_Database::get_results( $vote->id );
				if ( ! $results ) {
					continue;
				}
			}

			// Check if user can view results.
			if ( ! WPVP_Permissions::can_view_results( $user_id, $vote->id ) ) {
				continue;
			}

			$votes_with_results[] = $vote;
		}

		// Render the list.
		ob_start();
		$votes = $votes_with_results; // Template expects $votes variable.
		$is_results_context = true; // Flag for template to know this is results list context.
		include WPVP_PLUGIN_DIR . 'templates/public/vote-list.php';
		return ob_get_clean();
	}


	/**
	 * Register Elementor widgets (when Elementor is active).
	 */
	public function register_elementor_widgets( $widgets_manager ): void {
		// Only register if Elementor's base widget class exists.
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		require_once WPVP_PLUGIN_DIR . 'includes/public/class-elementor-widgets.php';

		if ( class_exists( 'WPVP_Elementor_Vote_List_Widget' ) ) {
			$widgets_manager->register( new WPVP_Elementor_Vote_List_Widget() );
		}
		if ( class_exists( 'WPVP_Elementor_Vote_Widget' ) ) {
			$widgets_manager->register( new WPVP_Elementor_Vote_Widget() );
		}
		if ( class_exists( 'WPVP_Elementor_Results_Widget' ) ) {
			$widgets_manager->register( new WPVP_Elementor_Results_Widget() );
		}
	}
}
