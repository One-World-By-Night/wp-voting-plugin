<?php
function user_search_vote_list_shortcode()
{

    $voteList = getUserVoteList();
    ob_start();

    // Your HTML content or function calls to generate the preview content
?>
    <section class="owbnVP vote--result">
        <div class="vote--wrapper">
            <div class="vote--row">
                <div class="col">
                    <div class="vote--result--area">
                        <div class="container">

                            <table id="example" class="display" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Proposal Name</th>
                                        <th>Ballot Type</th>
                                        <th>Opening Date</th>
                                        <th>Closing Date</th>
                                        <th>Voting Stage</th>
                                        <th>Result</th>
                                    </tr>
                                </thead>
                                <tbody>



                                </tbody>
                                                                <!-- <tfoot>
                                    <tr>
                                        <th>ID</th>
                                        <th>Proposal Name</th>
                                        <th>Vote Type</th>
                                        <th>Closing Date</th>
                                        <th>Opening Date</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot> -->
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function() {
            var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
            var username = $('.arm_data_value').first().text();

            // Initialize DataTable
            var dataTable = $('#example').DataTable({
                ajax: {
                    url: ajaxurl,
                    type: 'POST',
                    data: function(d) {
                        d.action = 'fetch_data_user_search_vote_list';
                        d.username = username;
                    },
                    dataSrc: function(json) {
                        return json.data;
                    }
                },
                columns: [{
                        data: 'id',
                        orderable: false
                    },
                    {
                        data: 'proposal_name',
                        orderable: false
                    },
                    {
                        data: 'vote_type',
                        orderable: false
                    },
                    {
                        data: 'opening_date',
                        orderable: false
                    },
                    {
                        data: 'closing_date',
                        orderable: false
                    },
                    {
                        data: 'voting_stage',
                        orderable: false
                    },
                    {
                        data: 'vote_box',
                        orderable: false,
                        render: function(data, type, row) {
                            return `<a href="<?php echo site_url(); ?>/owbn-voting-result/?id=${row.id}">View</a>`;
                        }
                    }
                ],
                pageLength: 10,
                serverSide: true,
                processing: true,
                order: [
                    [3, 'desc']
                ], // Order by opening_date
            });
            console.log(dataTable)

            // Listen for changes in the page length dropdown
            $('#pageLength').change(function() {
                let newLength = $(this).val();
                dataTable.page.len(newLength).draw();
            });
        });
    </script>



<?php

    return ob_get_clean();
    // }
}
add_shortcode('user_search_vote_list', 'user_search_vote_list_shortcode');

// Add AJAX action for logged-in users
add_action('wp_ajax_fetch_data_user_search_vote_list', 'fetch_data_user_search_vote_list');

// Add AJAX action for non-logged-in users (if needed)
add_action('wp_ajax_nopriv_fetch_data_user_search_vote_list', 'fetch_data_user_search_vote_list');

function fetch_data_user_search_vote_list()
{
    global $wpdb;

    // Retrieve pagination and search parameters
    $start = isset($_POST['start']) ? intval($_POST['start']) : 0;
    $length = isset($_POST['length']) ? intval($_POST['length']) : 10;
    $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
    $search_value = isset($_POST['search']['value']) ? sanitize_text_field($_POST['search']['value']) : '';

    // Validate username
    // $user = get_user_by('login', $username);
    // if (!$user) {
    //     wp_send_json_error('User not found');
    //     wp_die();
    // }

    // Prepare SQL query with search and LIMIT for pagination
    $table_name = $wpdb->prefix . 'voting';

    // Construct query
    // $query = $wpdb->prepare(
    //     "SELECT id, proposal_name, vote_type, opening_date, closing_date, vote_box 
    //      FROM $table_name 
    //      WHERE voting_stage = %s AND visibility = %s 
    //      AND (proposal_name LIKE %s OR vote_type LIKE %s)
    //      ORDER BY opening_date DESC 
    //      LIMIT %d, %d",
    //     'completed',
    //     'both',
    //     '%' . $wpdb->esc_like($search_value) . '%',
    //     '%' . $wpdb->esc_like($search_value) . '%',
    //     $start,
    //     $length
    // );
    $query = $wpdb->prepare(
        "SELECT id, proposal_name, vote_type, opening_date, closing_date, vote_box, voting_stage
         FROM $table_name 
         WHERE (voting_stage = %s OR voting_stage = %s) 
         AND visibility = %s 
         AND (proposal_name LIKE %s OR vote_type LIKE %s) 
         AND closing_date <= CURDATE()
         ORDER BY opening_date DESC 
         LIMIT %d, %d",
        'completed',
        'withdrawn',
        'both',
        '%' . $wpdb->esc_like($search_value) . '%',
        '%' . $wpdb->esc_like($search_value) . '%',
        $start,
        $length
    );
    
    // Execute query
    $results = $wpdb->get_results($query, ARRAY_A);
// print_r($results);
    // Count total records (for pagination)
    $total_records = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) 
         FROM $table_name 
           WHERE (voting_stage = %s OR voting_stage = %s) 
         AND visibility = %s 
         AND (proposal_name LIKE %s OR vote_type LIKE %s)
         AND closing_date <= CURDATE()
         
         ",
         
        'completed',
        'withdrawn',
        'both',
        '%' . $wpdb->esc_like($search_value) . '%',
        '%' . $wpdb->esc_like($search_value) . '%'
    ));

    // Return data as JSON
    echo json_encode([
        'draw' => intval($_POST['draw']),
        'recordsTotal' => intval($total_records),
        'recordsFiltered' => intval($total_records),
        'data' => $results,
        'user' => $user
    ]);
    wp_die();
}
