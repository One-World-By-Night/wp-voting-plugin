<?php
function voting_box_shortcode()
{

    // Check if the user is logged in and if the user has the 'administrator' or 'author' role
    if (!is_user_logged_in() || (!current_user_can('administrator') && !current_user_can('author'))) {
        wp_die('You do not have permission to access this page.');
    }

    $current_user = wp_get_current_user();

    // Get the current user ID
    $current_user_id = $current_user->ID;

    // Get the current user's display name
    $current_user_name = $current_user->display_name;

    $vote_id = isset($_GET['id']) ? intval($_GET['id']) : null;

    // Retrieve vote data based on the ID
    $vote_data = $vote_id !== null ? get_vote_data_by_id($vote_id) : null;

    // Initialize variables
    $content = '';
    $voting_choice = '';
    $voting_options_json = json_encode([]);
    $vote_box_json = json_encode([]);
    $vote_type = '';
    $opening_date = '';
    $closing_date = '';
    $current_user_vote = '';
    $current_user_comment = '';

    // If vote data is found, populate form fields for editing
    if ($vote_data) {
        $proposal_name = $vote_data['proposal_name'];
        $content = $vote_data['content'];
        $voting_choice = $vote_data['voting_choice'];
        $vote_box = $vote_data['vote_box'];
        $voting_options = unserialize($vote_data['voting_options']);
        $vote_type = $vote_data['vote_type'];
        $opening_date = $vote_data['opening_date'];
        $closing_date = $vote_data['closing_date'];
        $files_name = unserialize($vote_data['files_name']);

        // Encode
        $voting_options_json = json_encode($voting_options);
        // Decode
        $vote_box_array = json_decode($vote_box, true);

        // Check if the current user has already voted
        if ($vote_box_array) {
            foreach ($vote_box_array as $vote) {
                if ($vote['userId'] == $current_user_id) {
                    $current_user_vote = $vote['userVote'];
                    $current_user_comment = $vote['userComment'];
                    break;
                }
            }
        }
        if ($voting_choice !== 'single') {
            $current_user_vote = json_encode($current_user_vote);
        }
    } else {
        wp_die('Vote box is not valid');
    }
    $opening_date_str = strtotime($opening_date); // Opening date
    $closing_date_str = strtotime($closing_date); // Closing date

    if ($vote_data['active_status'] != 'activeVote' || time() < $opening_date_str || time() > $closing_date_str) {
        wp_die('Voting is not open.');
    }


    ob_start();
?>
    <section class="owbnVP bg--black voting_box">
        <div class="section-wrapper">
            <div class="row ">
                <div class="user_dashboard_vote">
                    <div class="user-title">
                        <h1>Vote For: <?php echo esc_attr($proposal_name); ?> </h1>
                    </div>
                    <div class="proposedby">
                        <div class="proposal--type">
                            <span><b>Proposed By : </b></span>
                            <span><?php echo esc_attr($vote_data['proposed_by']); ?></span>
                        </div>
                        <div class="proposal--type">
                            <span><b>Seconded By:</b></span>
                            <span><?php echo esc_attr($vote_data['seconded_by']); ?> </span>
                        </div>
                    </div>
                    <div class="proposal-type">
                        <span class="vote-roposal"><strong>Proposal Type :
                            </strong><?php echo esc_attr($vote_type); ?></span>
                        <span class="vote-open"><strong>Opened : </strong><?php echo date('m/d/Y h:iA', strtotime(esc_attr($opening_date))); ?>
                            <?php echo get_timezone_abbreviation(); ?></span>
                        <span class="vote-close"><strong>Closing : </strong><?php echo date('m/d/Y h:iA', strtotime(esc_attr($closing_date))); ?>
                            <?php echo get_timezone_abbreviation(); ?></span>
                    </div>



                    <!-- Files -->
                    <?php
                                    if ($vote_id) {
                                        if (!empty($files_name)) {
                                            foreach ($files_name as $option) {
                                                //!is_user_logged_in() || (!current_user_can('administrator') && !current_user_can('author'))
                                                if ((current_user_can('author') && $option['display'] == 1) || current_user_can('administrator')) {
                                                    //  print_r($option);

                                    ?> 
                    <div class="proposal--name file--document">
                        <h5>File / Document</h5>

                        <div class="table--box">
                            <table class="file--information--table" id="fileInfoTable">
                          
                                <thead>
                                    <tr>
                                        <th>File </th>
                                        <th>Description</th>

                                    </tr>
                                </thead>
                               
                                <tbody>
                                    <?php
                                    if ($vote_id) {
                                        if (!empty($files_name)) {
                                            foreach ($files_name as $option) {
                                                //!is_user_logged_in() || (!current_user_can('administrator') && !current_user_can('author'))
                                                if ((current_user_can('author') && $option['display'] == 1) || current_user_can('administrator')) {
                                                    //  print_r($option);

                                    ?>
                                                    <tr>
                                                        <td>
                                                            <div class="file--name">
                                                                <p><a target="_blank" href="<?php if (isset($option['id'])) {
                                                                                                echo wp_get_attachment_url($option['id']);
                                                                                            } ?>"><?php echo esc_html($option['fileName']); ?><span>(<?php echo esc_html($option['fileSize']); ?>
                                                                            bytes)</span></a></p>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div><?php echo esc_html($option['description']); ?></div>
                                                        </td>
                                                    </tr>
                                                <?php } ?>

                                    <?php }
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php } ?>

<?php }
    }
}
?>
                    
                    <div class="proposal-paragraph">
                    <h5>Vote Description</h5>
                        <?php echo wp_kses_post($content); ?>
                    </div>
                    <div class="vote-info">
                        <div class="spacer"></div>
                        <h4>Ballot Options</h4>
                        <form class="custom-form" id="votingForm">
                            <div id="votingOptionsContainer">
                                <!-- Form elements generated by JS will go here -->
                            </div>
                            <div style="width: 100%">

                                <div>
                                    <h4 style="margin: 20px 0;">Comment: </h4>
                                    <textarea id="owbn-user-comment" name="owbn-comment"><?php echo $current_user_comment ? esc_textarea($current_user_comment) : ''; ?></textarea>
                                </div>
                                <div class="save--btn-box mb--30 custom--btns">
                                    <button type="button" class="cust--btn submitbtn votebtn" onclick="submitVote(<?php echo $vote_id; ?>, <?php echo $current_user_id; ?>, '<?php echo $current_user_name; ?>', '<?php echo $voting_choice; ?>')">
                                        Let's Vote
                                    </button>
                                </div>
                            </div>
                        </form>

                    </div>

                </div>
            </div>
        </div>
    </section>

    <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function() {
            var votingChoice = "<?php echo $voting_choice; ?>";
            var userId = "<?php echo $current_user_id; ?>";
            var userName = "<?php echo $current_user_name; ?>";
            var votingOptions = <?php echo $voting_options_json; ?>;
            var voteBoxPhp = <?php echo $vote_box; ?>;
            console.log(voteBoxPhp)
            console.log(votingChoice)

            voteBox = voteBoxPhp;


            var votingOptionsContainer = document.getElementById("votingOptionsContainer");
            if (votingChoice !== 'single') {
                var selectedValuesContainer = document.createElement('div');
                selectedValuesContainer.id = 'selectedValuesContainer';
                votingOptionsContainer.after(selectedValuesContainer);
            }




            var singleValue = "";
            var multipleValues = [];

            var singleUserVote = votingChoice === 'single' ? <?php echo json_encode($current_user_vote); ?> : "";
            console.log(singleUserVote)
            var multipleUserVote = votingChoice !== 'single' ? JSON.parse('<?php echo $current_user_vote; ?>') : [];
            console.log(multipleUserVote)

            if (votingChoice === "single") {

                if (singleUserVote !== 'null') {
                    singleChoice = singleUserVote;
                    singleValue = singleUserVote;
                    console.log(singleValue)
                }
                votingOptions.forEach(function(option) {
                    var label = document.createElement("label");
                    const selected = singleUserVote && option.text === singleUserVote ? 'checked' : '';
                    label.innerHTML = '<input type="radio" name="option" class="radiobtn" value="' + option
                        .text + '" ' + selected + '> ' + option.text + '<br>';
                    votingOptionsContainer.appendChild(label);
                });

                // Handle radio button change
                votingOptionsContainer.addEventListener("change", function(event) {
                    if (event.target.classList.contains("radiobtn")) {
                        singleValue = event.target.value;
                        singleChoice = singleValue
                        console.log("Single Value: ", singleChoice);
                    }
                });
            } else if (votingChoice !== "single") {
                if (multipleUserVote !== 'null' && multipleUserVote) {
                    multipleValues = multipleUserVote;
                    multipleChoices = multipleUserVote;
                    updateSelectedValuesContainer();
                }

                votingOptions.forEach(function(option) {
                    var label = document.createElement("label");
                    const selected = multipleUserVote && multipleUserVote.includes(option.text) ? 'checked' :
                        '';
                    label.innerHTML = '<input type="checkbox" name="option" class="checkbox" value="' + option
                        .text +
                        '" ' + selected + '> ' + option.text + '<br>';
                    votingOptionsContainer.appendChild(label);
                });

                // Handle checkbox change
                votingOptionsContainer.addEventListener("change", function(event) {
                    if (event.target.classList.contains("checkbox")) {
                        if (event.target.checked) {
                            multipleValues.push(event.target.value);
                            multipleChoices = multipleValues
                        } else {
                            var index = multipleValues.indexOf(event.target.value);
                            if (index > -1) {
                                multipleValues.splice(index, 1);
                                multipleChoices = multipleValues
                            }
                        }
                        console.log("Multiple Values: ", multipleChoices);
                        updateSelectedValuesContainer();
                    }
                });
            }

            // Function to update the selected values container
            function updateSelectedValuesContainer() {
                selectedValuesContainer.innerHTML = '';
                if (multipleChoices !== 'null' && multipleChoices.length > 0) {
                    console.log(multipleChoices)
                    var list = document.createElement('ol');
                    multipleChoices && multipleChoices.forEach(function(value) {
                        var listItem = document.createElement('li');
                        listItem.textContent = value;
                        list.appendChild(listItem);
                    });
                    selectedValuesContainer.appendChild(list);
                } else {
                    selectedValuesContainer.textContent = 'No options selected';
                }
            }
        });
    </script>
<?php

    return ob_get_clean();
}

add_shortcode('voting_box', 'voting_box_shortcode');
